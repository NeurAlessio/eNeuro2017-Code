# Defines output directory
#cd("")

# Loads packages
using PyPlot
PyPlot.hold(false)

# Include STG model
include("STG.jl")
include("burstiness_map.jl")

# Simulation parameters
const T = 3000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const C = 1.
const VNa = 50.
const VK = -80.
const VCa = 80.
const Vleak = -50.
const gleak = 0.1
const gNa = 1200.
const gCaT = 10.  #1.-3.
const gCaS = 1.
const gA = 100. #40. 80.
const gKd = 80. # 60. # 80.
const gKCa = 50. # 40. # 25.
const Iapp = 1.

# Simulation (Iapp)
PyPlot.close("all")

# simulateSTG(V0,C,Iapp,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time (V,spk_times) = simulateSTG(-60.,1.,1.,1200.,1.,32.,40.,150.,120.)
ISIs = remove0(ISIfunc(spk_times))
ISIs = ISIs[1:end-1]
ISIs = ISIs[find(ISIs .< maximum(ISIs)/2)]
figure(1)
subplot(2,1,1)
Vplot = plot(t,V,"-")
axis([1500,2000,-80,60])
subplot(2,1,2)
bar(linspace(0,length(ISIs),length(ISIs)),ISIs)
savefig("Vplot_STG1.eps")

@time (V,spk_times) = simulateSTG(-60.,1.,1.,1200.,1.,40.5,40.,200.,200.)
ISIs = remove0(ISIfunc(spk_times))
ISIs = ISIs[1:end-1]
ISIs = ISIs[find(ISIs .< maximum(ISIs)/2)]
figure(2)
subplot(2,1,1)
Vplot = plot(t,V,"-")
axis([1500,2000,-80,60])
subplot(2,1,2)
bar(linspace(0,length(ISIs),length(ISIs)),ISIs)
savefig("Vplot_STG2.eps")

@time (V,spk_times) = simulateSTG(-60.,1.,1.,1200.,10.,8.,10.,120.,50.)
ISIs = remove0(ISIfunc(spk_times))
ISIs = ISIs[1:end-1]
ISIs = ISIs[find(ISIs .< maximum(ISIs)/2)]
figure(3)
subplot(2,1,1)
Vplot = plot(t,V,"-")
axis([1500,2000,-80,60])
subplot(2,1,2)
bar(linspace(0,length(ISIs),length(ISIs)),ISIs)
savefig("Vplot_STG3.eps")

@time (V,spk_times) = simulateSTG(-60.,1.,1.,1200.,1.,7.,8.,40.,13.)
ISIs = remove0(ISIfunc(spk_times))
ISIs = ISIs[1:end-1]
ISIs = ISIs[find(ISIs .< maximum(ISIs)/1.5)]
figure(4)
subplot(2,1,1)
Vplot = plot(t,V,"-")
axis([1500,2000,-80,60])
subplot(2,1,2)
bar(linspace(0,length(ISIs),length(ISIs)),ISIs)
savefig("Vplot_STG4.eps")

@time (V,spk_times) = simulateSTG(-60.,1.,1.,1200.,1.,4.,10.,40.,8.)
ISIs = remove0(ISIfunc(spk_times))
ISIs = ISIs[1:end-1]
ISIs = ISIs[find(ISIs .< maximum(ISIs)/1.5)]
figure(5)
subplot(2,1,1)
Vplot = plot(t,V,"-")
axis([1500,2000,-80,60])
subplot(2,1,2)
bar(linspace(0,length(ISIs),length(ISIs)),ISIs)
savefig("Vplot_STG5.eps")

@time (V,spk_times) = simulateSTG(-60.,1.,1.,1200.,10.,8.,10.,120.,40.)
ISIs = remove0(ISIfunc(spk_times))
ISIs = ISIs[1:end-1]
ISIs = ISIs[find(ISIs .< maximum(ISIs)/2)]
figure(6)
subplot(2,1,1)
Vplot = plot(t,V,"-")
axis([1500,2000,-80,60])
subplot(2,1,2)
bar(linspace(0,length(ISIs),length(ISIs)),ISIs)
savefig("Vplot_STG6.eps")
