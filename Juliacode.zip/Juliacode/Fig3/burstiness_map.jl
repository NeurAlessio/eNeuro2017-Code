# Functions
function ISIfunc(Spkt::Array{Float64})   # Computes the interspike intervals out of spike times
  ISI = zeros(length(Spkt))
  l::Int64 = 1
  for i = 2:length(Spkt)
      ISI[l] = Spkt[i] - Spkt[i-1]
      l += 1
  end
  return ISI
end

function remove0(ISI::Array{Float64})    # Removes 0's in spike times/interspike intervals vectors
  f = find(ISI .== 0)
    if f[1] > 1
      ISI = ISI[1:f[1]-1]
    else
      ISI = [0.]
    end
  return ISI
end


function isbursting(ISI::Array{Float64})   # Check if the neuron is bursting using the rule 3*minISI < maxISI
  bursting::Int64 = 0
  if minimum(ISI)*3 < maximum(ISI)
      bursting = 1
  end
  return bursting
end

function SPB_PER_DC_IBFfunc(ISI::Array{Float64}) # Computes spike per burst (SPB), period (PER), duty cycle (DC) and mean intraburst frequency of bursting neurons.
  minISI = minimum(ISI)
  maxISI = maximum(ISI)
  interburst = find(ISI .>= maxISI/3)
  intraburst = find(ISI .<= maxISI/3)
  SPB = round(length(intraburst)/length(interburst))+1
  IBP = mean(ISI[intraburst])
  Burstdur = IBP*(SPB-1)
  PER = Burstdur+mean(ISI[interburst])
  DC = Burstdur/PER
  IBF = 1000/IBP
  return (SPB, PER, DC, IBF)
end

function compute_params(spk_ncells::Array{Float64},Ttransient::Int64) # Extracts frequency or (SPB, PER, DC and IBF) out of the spiketimes saved in the Spkt$n.dat files. The number of cells is given by the number of lines in gs.
   ISIs = zeros(5000)
   PARAMS = zeros(1,4) #[SPB;PER;DC;IBF]
   freq = 0.

   f1 = find(spk_ncells .>= Ttransient) #Removes the transient of depol period
   f2 = find(spk_ncells .== 0) #Removes the zeros at the end of the vector

   if length(f1) == 0
     Spkt = [0.]
   else
     Spkt = spk_ncells[f1[1]:f2[1]-1]
   end

   ISI = ISIfunc(Spkt)
   ISItemp = remove0(ISI)

   if isbursting(ISItemp) == 1
     (PARAMS[1,1],PARAMS[1,2],PARAMS[1,3],PARAMS[1,4]) = SPB_PER_DC_IBFfunc(ISItemp)
     freq = 0.
   else
     PARAMS[1,:] = 0.
     freq = 1000/mean(ISItemp)
   end

   ISIs = [ISIs ISI]

 return PARAMS, freq
end
