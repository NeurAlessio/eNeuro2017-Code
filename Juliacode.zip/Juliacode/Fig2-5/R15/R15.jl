# gating functions
V2(V::Float64) = (127/105)*V + (8265/105)
alpham(V::Float64) = 0.1*(V2(V)-50)/(1-exp((V2(V)-50)/-10))
betam(V::Float64) = 4*exp((V2(V)-25)/-18)
minf(V::Float64) = alpham(V)/(alpham(V)+betam(V))
alphah(V::Float64) = 0.07*exp((V2(V)-25)/-20)
betah(V::Float64) = exp((V2(V)-55)/10)/(1+exp((V2(V)-55)/10))
hinf(V::Float64) = alphah(V)/(alphah(V)+betah(V))
tauh(V::Float64) = 12.5/(alphah(V)+betah(V))
alphan(V::Float64) = 0.01*(V2(V)-55)/(1-exp((V2(V)-55)/-10))
betan(V::Float64) = 0.125*exp((V2(V)-45)/-80)
ninf(V::Float64) = alphan(V)/(alphan(V)+betan(V))
taun(V::Float64) = 12.5/(alphan(V)+betan(V))
dinf(V::Float64) = 1/(exp(-0.15*(V+50))+1)
taud = 235

function dV(C::Float64, V::Float64, h::Float64, n::Float64, d::Float64, c::Float64)
  (dt)*(1/C)*(-gNa*minf(V)^3*h*(V-VNa) -gCa*d*(V-VCa) -(gKd*n^4 +gKCa*c/(0.5+c))*(V-VK) -gl*(V-Vl) + Iapp)
end
dh(V::Float64,h::Float64) = (dt)*((1/tauh(V))*(hinf(V) - h))
dn(V::Float64,n::Float64) = (dt)*((1/taun(V))*(ninf(V) - n))
dd(V::Float64,d::Float64) = (dt)*((1/taud)*(dinf(V) - d))
dc(V::Float64,d::Float64,c::Float64) = (dt)*(f*(k1*d*(VCa-V) - c))

function simulateR15(C::Float64)
  V::Float64=-70.
  Vprev::Float64=-70.
  h::Float64=hinf(V)
  n::Float64=ninf(V)
  d::Float64=dinf(V)
  c::Float64 = k1*d*(VCa-V)

  VV = zeros(Tdt)

  for z = 1:Tdt
    V += dV(C,V,h,n,d,c)
    c += dc(Vprev,d,c)
    h += dh(Vprev,h)
    n += dn(Vprev,n)
    d += dd(Vprev,d)

    Vprev = copy(V)
    VV[z] = copy(V)
  end

  return VV
end
