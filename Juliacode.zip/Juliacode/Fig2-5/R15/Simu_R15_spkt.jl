# Defines output directory
#cd("")

# Loads packages
using PyPlot
PyPlot.hold(false)

# Include model
include("R15_spkt.jl")
include("burstiness_map.jl")

# Simulation parameters
const T = 210000
const Ttransient = 10000
const dt = 0.1
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const nsimu = 100
const z = 1.
const C = 1.
const VCa = 140.
const VK = -75.
const VNa = 30.
const Vl = -40.
const gNa = 4.*z
const gKd = 0.3*z
const gCa = 0.006*z #0.3-1
const gKCa = 0.04*z
const gl = 0.003*z
const k1 = 0.0085
const f = 0.0003
const lambda = 1/12.5

const Iapp = 0.

function simulateR15_loop(nsimu,var)
  (spktimes,spkh) = simulateR15_spkt(gNa,gKd,gCa,gKCa,gl)
  spkt_height_nominal = mean(remove0(spkh))
  (PARAMS_nominal,freq_nominal) = compute_params(spktimes,Ttransient)
  variability = 1+(2*rand(nsimu,1)-1).*var
  gNavec = gNa.*variability
  gKdvec = gKd.*variability
  gCavec = gCa.*variability
  gKCavec = gKCa.*variability
  glvec = gl.*variability
  spkt_height = zeros(nsimu,1)
  PARAMS = zeros(nsimu,4)
  freq = zeros(nsimu,1)
  for i=1:nsimu
    (spktimes,spkh) = simulateR15_spkt(gNavec[i],gKdvec[i],gCavec[i],gKCavec[i],glvec[i])
    spkt_height[i] = mean(remove0(spkh))
    (PARAMS[i,:],freq[i]) = compute_params(spktimes,Ttransient)
  end
  return PARAMS_nominal,freq_nominal,spkt_height_nominal,PARAMS,freq,spkt_height
end


# Simulations
@time (PARAMS_nominal,freq_nominal,spkt_height_nominal,PARAMS1,freq1,spk_height1) = simulateR15_loop(nsimu,0.12))

PyPlot.close("all")
figure(1)
PyPlot.hold(true)
plot(rand(length(PARAMS1[find(PARAMS1[:,1].>0),1])),log(PARAMS1[find(PARAMS1[:,1].>0),1]/PARAMS_nominal[1]),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-1.5,1.6])
PyPlot.hold(false)
savefig("SPB.eps")

figure(2)
PyPlot.hold(true)
plot(rand(length(PARAMS1[find(PARAMS1[:,2].>0),2])),log(PARAMS1[find(PARAMS1[:,2].>0),2]/PARAMS_nominal[2]),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-1,0.4])
PyPlot.hold(false)
savefig("PER.eps")

figure(3)
PyPlot.hold(true)
plot(rand(length(PARAMS1[find(PARAMS1[:,3].>0),3])),log(PARAMS1[find(PARAMS1[:,3].>0),3]/PARAMS_nominal[3]),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-1,0.4])
PyPlot.hold(false)
savefig("DC.eps")

figure(4)
PyPlot.hold(true)
plot(rand(length(PARAMS1[find(PARAMS1[:,4].>0),4])),log(PARAMS1[find(PARAMS1[:,4].>0),4]/PARAMS_nominal[4]),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-0.6,1.1])
PyPlot.hold(false)
savefig("IBF.eps")

figure(5)
PyPlot.hold(true)
plot(rand(length(freq1[find(freq1.>0)])),log(freq1[find(freq1.>0)]/freq_nominal),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
PyPlot.hold(false)
savefig("freq.eps")

figure(6)
PyPlot.hold(true)
plot(rand(length(spk_height1)),spk_height1/spkt_height_nominal,"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-0.5,1.3])
PyPlot.hold(false)
savefig("Spike_height.eps")
