# Defines output directory
#cd("")

# Loads packages
using PyPlot
PyPlot.hold(false)

# Include model
include("R15.jl")

# Simulation parameters
const T = 100000
const Ttransient = 1000
const dt = 0.1
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const nsimu = 10
const z = 1.
const C = 1.
const VCa = 140.
const VK = -75.
const VNa = 30.
const Vl = -40.
const gNa = 4.*z
const gKd = 0.3*z
const gCa = 0.006*z #0.3-1
const gKCa = 0.04*z
const gl = 0.003*z
const k1 = 0.0085
const f = 0.0003
const lambda = 1/12.5

const Iapp = 0.

@time yy = simulateR15(1.)
@time yy2 = simulateR15(1./1.2)
@time yy3 = simulateR15(1./0.8)
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([46000,93000,-80,40])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([46000,93000,-80,40])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([46000,93000,-80,40])
savefig("Vplot_R15.eps")
