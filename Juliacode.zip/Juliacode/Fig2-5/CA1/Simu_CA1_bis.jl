# Defines output directory
cd("./")

# Loads packages
using PyPlot, SymPy
PyPlot.hold(true)

# Include DCN model
include("CA1.jl")

# Simulation parameters
const T = 3000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
#const C = 1.
const z = 1. #0.833
const VNa = 55
const VK = -90
const VCa = 120
const Vleak = -62
const gleak = 0.05*z
const gNa = 35*z
const gKd = 6*z
const gNaP = 0.3*z
const gA = 1.4*z
const gM = 1*z
const gc = 10*z #10*z
const gsAHP = 5*z #5*z
const gCa = 0.*z #0.2*z
const Iapp = 0.

#Bifurcation diagrams
#z , V = symbols("z,V", real=true)
PyPlot.close("all")
#SymPy.plot_implicit(dV_z_I(1.,V,z,Iapp,0.), (z,0.,1.), (V,-90.,50.), adaptive=false, points=500)
zloop_up=linspace(0.,0.3,200)
zloop_down=linspace(0.3,0.,200)
@time BIF=bif_diag(0.3,200,1.,Iapp)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
plot(zloop_up,BIFmin_up,marker=".",linestyle="")
plot(zloop_up,BIFmax_up,marker=".",linestyle="")
@time BIF=bif_diag(0.3,200,1./0.97,Iapp)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
plot(zloop_up,BIFmin_up,marker=".",linestyle="")
plot(zloop_up,BIFmax_up,marker=".",linestyle="")
@time BIF=bif_diag(0.3,200,1./0.92,Iapp)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
plot(zloop_up,BIFmin_up,marker=".",linestyle="")
plot(zloop_up,BIFmax_up,marker=".",linestyle="")
@time BIF=bif_diag(0.3,200,1./0.88,Iapp)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
plot(zloop_up,BIFmin_up,marker=".",linestyle="")
plot(zloop_up,BIFmax_up,marker=".",linestyle="")
@time BIF=bif_diag(0.3,200,1./1.2,Iapp)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
plot(zloop_up,BIFmin_up,marker=".",linestyle="")
plot(zloop_up,BIFmax_up,marker=".",linestyle="")
savefig("Bif_CA1_several.eps")
