# gating functions
minf(V::Float64) = -(V/10 + 7/2)/((exp(- V/10 - 7/2) - 1)*(4*exp(- V/18 - 10/3) - (V/10 + 7/2)/(exp(- V/10 - 7/2) - 1)))
taum(V::Float64) = 1/(4*exp(- V/18 - 10/3) - (V/10 + 7/2)/(exp(- V/10 - 7/2) - 1))
hinf(V::Float64) = (7*exp(- V/20 - 3))/(100*((7*exp(- V/20 - 3))/100 + 1/(exp(- V/10 - 3) + 1)))
tauh(V::Float64) = 1/((7*exp(- V/20 - 3))/100 + 1/(exp(- V/10 - 3) + 1))
ninf(V::Float64) = -(V + 50)/((100*exp(- V/10 - 5) - 100)*(exp(- V/80 - 3/4)/8 - (V + 50)/(100*exp(- V/10 - 5) - 100)))
taun(V::Float64) = 1/(exp(- V/80 - 3/4)/8 - (V + 50)/(100*exp(- V/10 - 5) - 100))

function dV(C::Float64,V::Float64, m::Float64, h::Float64, n::Float64, Ca::Float64, Iapp::Float64)
  (dt)*(1/C)*(-gCa*m^3*h*(V-VCa) -gKDR*n^4*(V-VK) -gKCa*(Ca/(Ca+Kd))*(V-VK) - gl*(V-Vl) + Iapp)
end
dm(V::Float64,m::Float64) = (dt)*((1/taum(V+Vprime))*(minf(V+Vprime) - m))
dh(V::Float64,h::Float64) = (dt)*((1/tauh(V+Vprime))*(hinf(V+Vprime) - h))
dn(V::Float64,n::Float64) = (dt)*((1/taun(V+Vstar))*(ninf(V+Vstar) - n))
dCa(V::Float64,m::Float64,h::Float64,Ca::Float64) = (dt)*(f*(-k1*gCa*m^3*h*(V-VCa) -kc*Ca))


function simulateBC(C::Float64,Iapp::Float64)
  V::Float64=-55.
  Vprev::Float64=-55.
  m::Float64=minf(V)
  h::Float64=hinf(V)
  n::Float64=ninf(V)
  Ca::Float64=0.6

  VV = zeros(Tdt)
  CCa = zeros(Tdt)

  for z = 1:Tdt
    V += dV(C,V,m,h,n,Ca,Iapp)
    Ca += dCa(Vprev,m,h,Ca)
    m += dm(Vprev,m)
    h += dh(Vprev,h)
    n += dn(Vprev,n)

    Vprev = copy(V)
    VV[z] = copy(V)
    CCa[z] = copy(Ca)
  end

  return VV, CCa
end


function simulateBC_Ca(C::Float64,Iapp::Float64,Ca::Float64,V0::Float64,m0::Float64,h0::Float64,n0::Float64)
  V::Float64=V0
  Vprev::Float64=V0
  m::Float64=m0
  h::Float64=h0
  n::Float64=n0

  VV = zeros(Tdt)

  for z = 1:Tdt
    V += dV(C,V,m,h,n,Ca,Iapp)
    m += dm(Vprev,m)
    h += dh(Vprev,h)
    n += dn(Vprev,n)

    Vprev = copy(V)
    VV[z] = copy(V)
  end

  return VV, m, h, n
end


function bif_diag(Camax::Float64,Calength::Int64,C::Float64,Iapp::Float64)
  V0::Float64=-0.
  m0::Float64=0.9
  h0::Float64=0.9
  n0::Float64=0.1

  yy=simulateBC_Ca(C,Iapp,0.,V0,m0,h0,n0)
  Vfin=yy[1]
  Vfin=Vfin[end]
  m0=yy[2]
  h0=yy[3]
  n0=yy[4]

  Caloop_up=linspace(1/Calength,Camax,Calength)
  Caloop_down=linspace(Camax,1/Calength,Calength)

  BIFmin_up=fill!(Array(Float64,Calength,1),NaN)
  BIFmax_up=fill!(Array(Float64,Calength,1),NaN)
  BIFmin_down=fill!(Array(Float64,Calength,1),NaN)
  BIFmax_down=fill!(Array(Float64,Calength,1),NaN)

  for i=1:length(Caloop_up)
    yy=simulateBC_Ca(C,Iapp,Caloop_up[i],Vfin,m0,h0,n0)
    Vfin=yy[1]
    BIFmin_up[i]=minimum(Vfin[ceil(Int64,Tdt/2):Tdt])
    BIFmax_up[i]=maximum(Vfin[ceil(Int64,Tdt/2):Tdt])
    Vfin=Vfin[end]
    m0=yy[2]
    h0=yy[3]
    n0=yy[4]
  end

  for i=1:length(Caloop_down)
    yy=simulateBC_Ca(C,Iapp,Caloop_down[i],Vfin,m0,h0,n0)
    Vfin=yy[1]
    BIFmin_down[i]=minimum(Vfin[ceil(Int64,Tdt/2):Tdt])
    BIFmax_down[i]=maximum(Vfin[ceil(Int64,Tdt/2):Tdt])
    Vfin=Vfin[end]
    m0=yy[2]
    h0=yy[3]
    n0=yy[4]
  end
  return BIFmin_up, BIFmax_up, BIFmin_down, BIFmax_down
end


mbif(V) = -(V/10 + 7/2)/((exp(- V/10 - 7/2) - 1)*(4*exp(- V/18 - 10/3) - (V/10 + 7/2)/(exp(- V/10 - 7/2) - 1)))
hbif(V) = (7*exp(- V/20 - 3))/(100*((7*exp(- V/20 - 3))/100 + 1/(exp(- V/10 - 3) + 1)))
nbif(V) = -(V + 50)/((100*exp(- V/10 - 5) - 100)*(exp(- V/80 - 3/4)/8 - (V + 50)/(100*exp(- V/10 - 5) - 100)))

dV_Ca_I(C::Float64,V,Ca,Iapp::Float64) =
-gCa*mbif(V+Vprime)^3*hbif(V+Vprime)*(V-VCa) -gKDR*nbif(V+Vstar)^4*(V-VK) -gKCa*(Ca/(Ca+Kd))*(V-VK) - gl*(V-Vl) + Iapp
