# Defines output directory
cd("./")

# Loads packages
using PyPlot
PyPlot.hold(true)

# Include DCN model
include("CA1_2.jl")

# Simulation parameters
const T = 3000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)
const dt2 = 0.0001
const Tdt2 = convert(Int64,T/dt2)
const t2 = linspace(dt2,T,Tdt2)
const Ttransient = 1000
const Ttransientdt = convert(Int64,Ttransient/dt)


# Model parameters
#const C = 1.
const z = 1. #0.833
const VNa = 55.
const VK = -90.
const VCa = 120.
const Vleak = -62.
const gleak = 0.05*z
const gNa = 35.*z
const gKd = 6.*z
const gNaP = 0.3*z
const gA = 1.4*z
const gM = 2.*z
const gc = 10.*z #10*z
const gsAHP = 5.*z #5*z
const gCa = 0.*z #0.2*z
const Iapp = 1.

const k1 = 0.3
const k2 = 1.3

# Simulation (Iapp)
N=4
j=1
Cvecplot=[0.1 1.0 1.4 10.0]
PyPlot.close("all")
figure
for i=1:length(Cvecplot)
    @time (VV,zz) = simulateCA1(Iapp,Cvecplot[i],VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
    subplot(ceil(N/j),j,i)
    Vplot = plot(t,VV,"-")
    axis([Ttransient,T,-100,60])
end
savefig("Vplot_CA1_Cplot.eps")


Cvec=logspace(-1.,10.,100)
FP=zeros(length(Cvec))
for i=1:length(Cvec)
    @time (spiketimesA, spiketimesB) = simulateCA1_spkt(Tdt,t,Iapp,Cvec[i],VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
    if sum(spiketimesA[2:end]) .== 0 && sum(spiketimesB[2:end]) .== 0
        FP[i] = 0. #Silent
    elseif sum(spiketimesA[2:end]) .> 0 && sum(spiketimesB[2:end]) .== 0
        FP[i] = 1. #Slow oscillation
    elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[2:end]))) ).== 1
        FP[i] = 2. #bursting
    else
        FP[i] = 3. #spiking
    end
end

Cveczoom=logspace(-0.1,0.4,100)
FPzoom=zeros(length(Cveczoom))
for i=1:length(Cveczoom)
    @time (spiketimesA, spiketimesB) = simulateCA1_spkt(Tdt,t,Iapp,Cveczoom[i],VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
    if sum(spiketimesA[2:end]) .== 0 && sum(spiketimesB[2:end]) .== 0
        FPzoom[i] = 0. #Silent
    elseif sum(spiketimesA[2:end]) .> 0 && sum(spiketimesB[2:end]) .== 0
        FPzoom[i] = 1. #Slow oscillation
    elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[2:end]))) ).== 1
        FPzoom[i] = 2. #bursting
    else
        FPzoom[i] = 3. #spiking
    end
end


Cvec2=logspace(-2.,-1.,10)
FP2=zeros(length(Cvec2))
for i=1:length(Cvec2)
    @time (spiketimesA, spiketimesB) = simulateCA1_spkt(Tdt2,t2,Iapp,Cvec2[i],VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
    if sum(spiketimesA[2:end]) .== 0 && sum(spiketimesB[2:end]) .== 0
        FP2[i] = 0. #Silent
    elseif sum(spiketimesA[2:end]) .> 0 && sum(spiketimesB[2:end]) .== 0
        FP2[i] = 1. #Slow oscillation
    elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[2:end]))) ).== 1
        FP2[i] = 2. #bursting
    else
        FP2[i] = 3. #spiking
    end
end

PyPlot.close("all")
figure
semilogx([Cvec2;Cveczoom;Cvec],[FP2;FPzoom;FP],"*")
xlim([0.005,200])
ylim([-1,4])
savefig("Vplot_CA1_FPvsC.eps")
