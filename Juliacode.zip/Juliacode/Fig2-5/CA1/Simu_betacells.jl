# Defines output directory
cd("./")

# Loads packages
using PyPlot, SymPy
PyPlot.hold(true)

# Include Connor-Stevens model
include("Betacells.jl")

# Simulation parameters
const T = 60000
const Ttransient = 10000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const nsimu = 100

const C = 1.
const VCa = 100.
const VK = -75.
const Vl = -40.
const k1 = 0.0275
const kc = 0.02
const f = 0.007
const Kd = 1.
const Vstar = 30-60
const Vprime = 50-60
const gl = 0.012
const gCa = 3.2
const gKDR = 3.
const gKCa = 0.02
const Iapp = -0.1
const Iapp2 = -0.1
const Iapp3 = -0.1
@time (VV,Caa) = simulateBC(1.,Iapp)
@time (VVbis,Caa2) = simulateBC(1./1.3,Iapp2)
@time (VV3,Caa3) = simulateBC(1./0.88,Iapp3)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,VV,"-")
axis([Ttransient,T,-80,0])
subplot(3,1,2)
Vplot = plot(t,VVbis,"-")
axis([Ttransient,T,-80,0])
subplot(3,1,3)
Vplot = plot(t,VV3,"-")
axis([Ttransient,T,-80,0])
savefig("Vplot_CK.eps")

#Bifurcation diagrams
Ca , V = symbols("Ca,V", real=true)
PyPlot.close("all")
SymPy.plot_implicit(dV_Ca_I(1.,V,Ca,Iapp), (Ca,0.,5.), (V,-90.,50.), adaptive=false, points=500)
plot(Caa[ceil(Int64,Tdt/2):Tdt],VV[ceil(Int64,Tdt/2):Tdt],"-",color="black")
xlim(0,2)
ylim(-80,0)
@time BIF=bif_diag(0.5,20,1.,Iapp)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
BIFmin_down=BIF[3]
BIFmax_down=BIF[4]
Caloop_up=linspace(1/20,0.5,20)
Caloop_down=linspace(0.5,1/20,20)
plot(Caloop_up,BIFmin_up,marker=".",linestyle="")
plot(Caloop_up,BIFmax_up,marker=".",linestyle="")
plot(Caloop_down,BIFmin_down,marker="*",linestyle="")
plot(Caloop_down,BIFmax_down,marker="*",linestyle="")
savefig("Bif_CK_1.eps")

PyPlot.close("all")
SymPy.plot_implicit(dV_Ca_I(1/1.3,V,Ca,Iapp2), (Ca,0.,5.), (V,-90.,50.), adaptive=false, points=500)
plot(Caa2[ceil(Int64,Tdt/2):Tdt],VVbis[ceil(Int64,Tdt/2):Tdt],"-",color="black")
xlim(0,2)
ylim(-80,0)
@time BIF=bif_diag(0.5,20,1/1.3,Iapp2)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
BIFmin_down=BIF[3]
BIFmax_down=BIF[4]
Caloop_up=linspace(1/20,0.5,20)
Caloop_down=linspace(0.5,1/20,20)
plot(Caloop_up,BIFmin_up,marker=".",linestyle="")
plot(Caloop_up,BIFmax_up,marker=".",linestyle="")
plot(Caloop_down,BIFmin_down,marker="*",linestyle="")
plot(Caloop_down,BIFmax_down,marker="*",linestyle="")
savefig("Bif_CK_13.eps")

PyPlot.close("all")
SymPy.plot_implicit(dV_Ca_I(1/0.88,V,Ca,Iapp3), (Ca,0.,5.), (V,-90.,50.), adaptive=false, points=500)
plot(Caa3[ceil(Int64,Tdt/2):Tdt],VV3[ceil(Int64,Tdt/2):Tdt],"-",color="black")
xlim(0,2)
ylim(-80,0)
@time BIF=bif_diag(1.5,120,1/0.88,Iapp3)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
BIFmin_down=BIF[3]
BIFmax_down=BIF[4]
Caloop_up=linspace(1/120,1.5,120)
Caloop_down=linspace(1.5,1/120,120)
plot(Caloop_up,BIFmin_up,marker=".",linestyle="")
plot(Caloop_up,BIFmax_up,marker=".",linestyle="")
plot(Caloop_down,BIFmin_down,marker="*",linestyle="")
plot(Caloop_down,BIFmax_down,marker="*",linestyle="")
savefig("Bif_CK_088.eps")
