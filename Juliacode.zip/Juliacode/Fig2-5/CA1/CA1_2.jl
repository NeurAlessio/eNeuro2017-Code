# Model from Golomb et al., 2006.

# gating functions
boltz(V::Float64,A::Float64,B::Float64) = 1/(1 + exp(-(V-A)/B))
tau(V::Float64,A::Float64,B::Float64,C::Float64,D::Float64) = A + B/(1+exp(-(V-C)/D))
minf(V::Float64) = boltz(V,-30.,9.5)
hinf(V::Float64) = boltz(V,-45.,-7.)
tauh(V::Float64) = tau(V,0.1,0.75,-40.5,-6.)
pinf(V::Float64) = boltz(V,-47.,3.) #-41 if calcium
ninf(V::Float64) = boltz(V,-35.,10.)
taun(V::Float64) = tau(V,0.1,0.5,-27.,-15.)
ainf(V::Float64) = boltz(V,-50.,20.)
binf(V::Float64) = boltz(V,-80.,-6.)
const taub = 15
zinf(V::Float64) = boltz(V,-39.,5.)
const tauz = 75
rinf(V::Float64) = boltz(V,-20.,10.)
const taur = 1
cinf(V::Float64) = boltz(V,-30.,7.)
const tauc = 2
dinf(Ca::Float64) = 1/(1+(6/Ca))
qinf(Ca::Float64) = 1/(1+(2^4/Ca^4))
const tauq = 450

function dV(C::Float64, V::Float64, h::Float64, n::Float64, b::Float64, z::Float64, r::Float64, c::Float64, q::Float64, Ca::Float64, Iapp::Float64, VNa::Float64,VK::Float64,VCa::Float64,Vleak::Float64,gleak::Float64,gNa::Float64,gKd::Float64,gNaP::Float64,gA::Float64,gM::Float64,gc::Float64,gsAHP::Float64,gCa::Float64)
  (dt)*(1/C)*(-gNa*minf(V)^3*h*(V-VNa) -gNaP*pinf(V)*(V-VNa) -gKd*n^4*(V-VK) -gA*ainf(V)^3*b*(V-VK) -gM*z*(V-VK) -gCa*r^2*(V-VCa) -gc*dinf(Ca)*c*(V-VK) -gsAHP*q*(V-VK) -gleak*(V-Vleak) + Iapp)
end
dh(V::Float64,h::Float64) = (dt)*((1/tauh(V))*(hinf(V) - h))
dn(V::Float64,n::Float64) = (dt)*((1/taun(V))*(ninf(V) - n))
db(V::Float64,b::Float64) = (dt)*((1/taub)*(binf(V) - b))
dz(V::Float64,z::Float64) = (dt)*((1/tauz)*(zinf(V) - z))
dr(V::Float64,r::Float64) = (dt)*((1/taur)*(rinf(V) - r))
dc(V::Float64,c::Float64) = (dt)*((1/tauc)*(cinf(V) - c))
dq(Ca::Float64,q::Float64) = (dt)*((1/tauq)*(qinf(Ca) - q))
dCa(V::Float64,r::Float64,Ca::Float64) = (dt)*(-0.13*(gCa*r^2*(V-VCa))-Ca/13)

function simulateCA1(Iapp::Float64,C::Float64,VNa::Float64,VK::Float64,VCa::Float64,Vleak::Float64,gleak::Float64,gNa::Float64,gKd::Float64,gNaP::Float64,gA::Float64,gM::Float64,gc::Float64,gsAHP::Float64,gCa::Float64)
  V::Float64=-60.
  Vprev::Float64=-60.
  Ca::Float64=0.5
  h::Float64=hinf(V)
  n::Float64=ninf(V)
  b::Float64=binf(V)
  z::Float64=zinf(V)
  r::Float64=rinf(V)
  c::Float64=cinf(V)
  q::Float64=qinf(Ca)

  VV = zeros(Tdt)
  zz = zeros(Tdt)

  for i = 1:Tdt
    V += dV(C, V, h, n, b, z, r, c, q, Ca, Iapp, VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
    q += dq(Ca,q)
    Ca += dCa(Vprev,r,Ca)
    h += dh(Vprev,h)
    n += dn(Vprev,n)
    b += db(Vprev,b)
    z += dz(Vprev,z)
    r += dr(Vprev,r)
    c += dc(Vprev,c)


    Vprev = copy(V)
    VV[i] = copy(V)
    zz[i] = copy(z)
  end

  return VV,zz
end


function simulateCA1_spkt(Tdtbis::Int64,tbis::LinSpace{Float64},Iapp::Float64,C::Float64,VNa::Float64,VK::Float64,VCa::Float64,Vleak::Float64,gleak::Float64,gNa::Float64,gKd::Float64,gNaP::Float64,gA::Float64,gM::Float64,gc::Float64,gsAHP::Float64,gCa::Float64)
  V::Float64=-60.
  Vprev::Float64=-60.
  Ca::Float64=0.5
  h::Float64=hinf(V)
  n::Float64=ninf(V)
  b::Float64=binf(V)
  z::Float64=zinf(V)
  r::Float64=rinf(V)
  c::Float64=cinf(V)
  q::Float64=qinf(Ca)

  spiketimesA = zeros(Tdtbis)
  l=1
  spiketimesB = zeros(Tdtbis)
  k=1

  for i = 1:Tdtbis
    V += dV(C, V, h, n, b, z, r, c, q, Ca, Iapp, VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
    q += dq(Ca,q)
    Ca += dCa(Vprev,r,Ca)
    h += dh(Vprev,h)
    n += dn(Vprev,n)
    b += db(Vprev,b)
    z += dz(Vprev,z)
    r += dr(Vprev,r)
    c += dc(Vprev,c)

    if Vprev < -50. && V >= -50.
        spiketimesA[l] = tbis[i]
        l += 1
    end
    if Vprev < -10. && V >= -10.
        spiketimesB[k] = tbis[i]
        k += 1
    end
    Vprev = copy(V)
  end

  return spiketimesA, spiketimesB
end

function ISIfunc(Spkt::Array{Float64})   # Computes the interspike intervals out of spike times
  ISI = zeros(5000000)
  l::Int64 = 1
  for i = 2:length(Spkt)
      ISI[l] = Spkt[i] - Spkt[i-1]
      l += 1
  end
  return ISI
end

function remove0(ISI::Array{Float64})    # Removes 0's in spike times/interspike intervals vectors
  f = find(ISI .== 0)
    if f[1] > 1
      ISI = ISI[1:f[1]-1]
    else
      ISI = [0]
    end
  return ISI
end


function isbursting(ISI::Array{Float64})   # Check if the neuron is bursting using the rule 3*minISI < maxISI
  bursting::Int64 = 0
  if minimum(ISI)*3 < maximum(ISI)
      bursting = 1
  end
  return bursting
end


function simulateCA1_z(Iapp::Float64,C::Float64,z::Float64,V0::Float64,h0::Float64,n0::Float64,b0::Float64,r0::Float64,c0::Float64,q0::Float64,Ca0::Float64)
  V::Float64=V0
  Vprev::Float64=V0
  Ca::Float64=Ca0
  h::Float64=h0
  n::Float64=n0
  b::Float64=b0
  r::Float64=r0
  c::Float64=c0
  q::Float64=q0

  VV = zeros(Tdt)

  for i = 1:Tdt
    V += dV(C, V, h, n, b, z, r, c, q, Ca, Iapp)
    q += dq(Ca,q)
    Ca += dCa(Vprev,r,Ca)
    h += dh(Vprev,h)
    n += dn(Vprev,n)
    b += db(Vprev,b)
    #z += dz(Vprev,z)
    r += dr(Vprev,r)
    c += dc(Vprev,c)


    Vprev = copy(V)
    VV[i] = copy(V)
  end

  return VV, h, n, b, r, c, q, Ca
end

function bif_diag(zmax::Float64,zlength::Int64,C::Float64,Iapp::Float64)
  V0::Float64=20.
  Ca0::Float64=0.5
  h0::Float64=hinf(V0)
  n0::Float64=ninf(V0)
  b0::Float64=binf(V0)
  r0::Float64=rinf(V0)
  c0::Float64=cinf(V0)
  q0::Float64=qinf(V0)

  yy=simulateCA1_z(Iapp,C,0.,V0,h0,n0,b0,r0,c0,q0,Ca0)
  Vfin=yy[1]
  Vfin=Vfin[end]
  h0=yy[2]
  n0=yy[3]
  b0=yy[4]
  r0=yy[5]
  c0=yy[6]
  q0=yy[7]
  Ca0=yy[8]

  zloop_up=linspace(0.,zmax,zlength)
  zloop_down=linspace(zmax,0.,zlength)

  BIFmin_up=fill!(Array(Float64,zlength,1),NaN)
  BIFmax_up=fill!(Array(Float64,zlength,1),NaN)
  BIFmin_down=fill!(Array(Float64,zlength,1),NaN)
  BIFmax_down=fill!(Array(Float64,zlength,1),NaN)

  for i=1:length(zloop_up)
    yy=simulateCA1_z(Iapp,C,zloop_up[i],Vfin,h0,n0,b0,r0,c0,q0,Ca0)
    Vfin=yy[1]
    BIFmin_up[i]=minimum(Vfin[ceil(Int64,Tdt/2):Tdt])
    BIFmax_up[i]=maximum(Vfin[ceil(Int64,Tdt/2):Tdt])
    Vfin=Vfin[end]
    h0=yy[2]
    n0=yy[3]
    b0=yy[4]
    r0=yy[5]
    c0=yy[6]
    q0=yy[7]
    Ca0=yy[8]
  end

  for i=1:length(zloop_down)
    yy=simulateCA1_z(Iapp,C,zloop_down[i],Vfin,h0,n0,b0,r0,c0,q0,Ca0)
    Vfin=yy[1]
    BIFmin_down[i]=minimum(Vfin[ceil(Int64,Tdt/2):Tdt])
    BIFmax_down[i]=maximum(Vfin[ceil(Int64,Tdt/2):Tdt])
    Vfin=Vfin[end]
    h0=yy[2]
    n0=yy[3]
    b0=yy[4]
    r0=yy[5]
    c0=yy[6]
    q0=yy[7]
    Ca0=yy[8]
  end
  return BIFmin_up, BIFmax_up, BIFmin_down, BIFmax_down
end

boltzbif(V,A::Float64,B::Float64) = 1/(1 + exp(-(V-A)/B))

mbif(V) = boltzbif(V,-30.,9.5)
hbif(V) = boltzbif(V,-45.,-7.)
pbif(V) = boltzbif(V,-47.,3.) #-41 if calcium
nbif(V) = boltzbif(V,-35.,10.)
abif(V) = boltzbif(V,-50.,20.)
bbif(V) = boltzbif(V,-80.,-6.)
rbif(V) = boltzbif(V,-20.,10.)
cbif(V) = boltzbif(V,-30.,7.)
dbif(Ca) = 1/(1+(6/Ca))
qbif(Ca) = 1/(1+(2^4/Ca^4))

dV_z_I(C::Float64,V,z,Iapp::Float64,Ca::Float64) =
  -gNa*mbif(V)^3*hbif(V)*(V-VNa) -gNaP*pbif(V)*(V-VNa) -gKd*nbif(V)^4*(V-VK) -gA*abif(V)^3*bbif(V)*(V-VK) -gM*z*(V-VK) -gCa*rbif(V)^2*(V-VCa) -gc*dbif(Ca)*cbif(V)*(V-VK) -gsAHP*qbif(Ca)*(V-VK) -gleak*(V-Vleak) + Iapp
