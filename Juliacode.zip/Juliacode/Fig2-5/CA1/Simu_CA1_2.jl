# Defines output directory
cd("./")

# Loads packages
using PyPlot
PyPlot.hold(true)

# Include DCN model
include("CA1_2.jl")

# Simulation parameters
const T = 2600
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
#const C = 1.
const z = 1. #0.833
const VNa = 55.
const VK = -90.
const VCa = 120.
const Vleak = -62.
const gleak = 0.05*z
const gNa = 35.*z
const gKd = 6.*z
const gNaP = 0.3*z
const gA = 1.4*z
const gM = 1.*z
const gc = 10.*z #10*z
const gsAHP = 5.*z #5*z
const gCa = 0.*z #0.2*z
const Iapp = 1.

const k1 = 0.3
const k2 = 1.3

# Simulation (Iapp)
@time (VV,zz) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV2,zz2) = simulateCA1(Iapp,1./1.2,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV3,zz3) = simulateCA1(Iapp,1./0.8,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,VV,"-")
axis([2000,T,-100,40])
subplot(3,1,2)
Vplot = plot(t,VV2,"-")
axis([2000,T,-100,40])
subplot(3,1,3)
Vplot = plot(t,VV3,"-")
axis([2000,T,-100,40])
savefig("Vplot_CA1_C.eps")


@time (VV,zz) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV2,zz2) = simulateCA1(Iapp,1.,VNa+20.,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV3,zz3) = simulateCA1(Iapp,1.,VNa-20.,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,VV,"-")
axis([2000,T,-100,40])
subplot(3,1,2)
Vplot = plot(t,VV2,"-")
axis([2000,T,-100,40])
subplot(3,1,3)
Vplot = plot(t,VV3,"-")
axis([2000,T,-100,40])
savefig("Vplot_CA1_VNa.eps")


@time (VV,zz) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV2,zz2) = simulateCA1(Iapp,1.,VNa,VK+5.,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV3,zz3) = simulateCA1(Iapp,1.,VNa,VK-5.,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,VV,"-")
axis([2000,T,-100,40])
subplot(3,1,2)
Vplot = plot(t,VV2,"-")
axis([2000,T,-100,40])
subplot(3,1,3)
Vplot = plot(t,VV3,"-")
axis([2000,T,-100,40])
savefig("Vplot_CA1_VK.eps")


@time (VV,zz) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV2,zz2) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa-k1*gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV3,zz3) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa+k1*gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,VV,"-")
axis([2000,T,-100,40])
subplot(3,1,2)
Vplot = plot(t,VV2,"-")
axis([2000,T,-100,40])
subplot(3,1,3)
Vplot = plot(t,VV3,"-")
axis([2000,T,-100,40])
savefig("Vplot_CA1_gNa.eps")



@time (VV,zz) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV2,zz2) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd-k1*gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV3,zz3) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd+k1*gKd,gNaP,gA,gM,gc,gsAHP,gCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,VV,"-")
axis([2000,T,-100,40])
subplot(3,1,2)
Vplot = plot(t,VV2,"-")
axis([2000,T,-100,40])
subplot(3,1,3)
Vplot = plot(t,VV3,"-")
axis([2000,T,-100,40])
savefig("Vplot_CA1_gK.eps")


@time (VV,zz) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV2,zz2) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP-0.6*gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV3,zz3) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP+k1*gNaP,gA,gM,gc,gsAHP,gCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,VV,"-")
axis([2000,T,-100,40])
subplot(3,1,2)
Vplot = plot(t,VV2,"-")
axis([2000,T,-100,40])
subplot(3,1,3)
Vplot = plot(t,VV3,"-")
axis([2000,T,-100,40])
savefig("Vplot_CA1_gNaP.eps")


@time (VV,zz) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV2,zz2) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA-k1*gA,gM,gc,gsAHP,gCa)
@time (VV3,zz3) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA+k1*gA,gM,gc,gsAHP,gCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,VV,"-")
axis([2000,T,-100,40])
subplot(3,1,2)
Vplot = plot(t,VV2,"-")
axis([2000,T,-100,40])
subplot(3,1,3)
Vplot = plot(t,VV3,"-")
axis([2000,T,-100,40])
savefig("Vplot_CA1_gA.eps")


@time (VV,zz) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa)
@time (VV2,zz2) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM-k1*gM,gc,gsAHP,gCa)
@time (VV3,zz3) = simulateCA1(Iapp,1.,VNa,VK,VCa,Vleak,gleak,gNa,gKd,gNaP,gA,gM+k1*gM,gc,gsAHP,gCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,VV,"-")
axis([2000,T,-100,40])
subplot(3,1,2)
Vplot = plot(t,VV2,"-")
axis([2000,T,-100,40])
subplot(3,1,3)
Vplot = plot(t,VV3,"-")
axis([2000,T,-100,40])
savefig("Vplot_CA1_gM.eps")


N=20
j=2
PyPlot.close("all")
figure
for i=1:N
    @time (VV,zz) = simulateCA1(Iapp,1.*(1+1/14-rand(1)[1]/7),VNa*(1+1/14-rand(1)[1]/7),VK*(1+1/14-rand(1)[1]/7),VCa*(1+1/14-rand(1)[1]/7),Vleak,gleak*(1+1/14-rand(1)[1]/7),gNa*(1+1/14-rand(1)[1]/7),gKd*(1+1/14-rand(1)[1]/7),gNaP*(1+1/14-rand(1)[1]/7),gA*(1+1/14-rand(1)[1]/7),gM*(1+1/14-rand(1)[1]/7),gc*(1+1/14-rand(1)[1]/7),gsAHP*(1+1/14-rand(1)[1]/7),gCa*(1+1/14-rand(1)[1]/7))
    subplot(N/j,j,i)
    Vplot = plot(t,VV,"-")
    axis([2000,T,-100,40])
end
savefig("Vplot_CA1_rand.eps")
