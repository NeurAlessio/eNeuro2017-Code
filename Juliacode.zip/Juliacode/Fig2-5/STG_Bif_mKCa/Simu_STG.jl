cd("./")

# Loads packages
using PyPlot, SymPy
PyPlot.hold(true)

# Simulation parameters
const T = 5000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Vclamp Simulation Parameters
const TVC = 100
const T0 = 1
const Tdt0 = convert(Int64,T0/dt)
const TdtVC = convert(Int64,TVC/dt)
const tVC = linspace(dt,TVC,TdtVC)

# Model parameters
const C = 1.
const VNa = 50.
const VK = -80.
const VCa = 80.
const Vleak = -50.
const gleak = 0.1
#const gNa = 700.#700.
#const gCaT = 2.5  #1.-3.
#const gCaS = 7.0 #gCaT*1.5
#const gA = 30. #40. 80.
#const gKd = 80. # 60. # 80.
#const gKCa = 25. # 40. # 25.
#const Iapp = 0.

# Include STG model
include("STG.jl")


#BURSTING (700.,1.5*6,6.,30.,80.,25.)
#Timecourses
@time yy1 = simulateSTG(1.,-20.,700.,1.5*6.,6.,30.,80.,25.)
VV1=yy1[1]
CCaa1=yy1[2]
Iapp1=yy1[3]
mKCaa1 = yy1[4]
PyPlot.close("all")
subplot(3,1,1)
plot(t,VV1)
subplot(3,1,2)
plot(t,mKCaa1)
subplot(3,1,3)
plot(t,CCaa1)
savefig("timeplot-bursting-1.eps")

@time yy1 = simulateSTG(0.6,-20.,700.,1.5*6.,6.,30.,80.,25.)
VV1bis=yy1[1]
CCaa1bis=yy1[2]
Iapp1bis=yy1[3]
mKCaa1bis = yy1[4]
PyPlot.close("all")
subplot(3,1,1)
plot(t,VV1bis)
subplot(3,1,2)
plot(t,mKCaa1bis)
subplot(3,1,3)
plot(t,CCaa1bis)
savefig("timeplot-bursting-06.eps")

@time yy1 = simulateSTG(0.1,-20.,700.,1.5*6.,6.,30.,80.,25.)
VV1ter=yy1[1]
CCaa1ter=yy1[2]
Iapp1ter=yy1[3]
mKCaa1ter = yy1[4]
PyPlot.close("all")
subplot(3,1,1)
plot(t,VV1ter)
subplot(3,1,2)
plot(t,mKCaa1ter)
subplot(3,1,3)
plot(t,CCaa1ter)
savefig("timeplot-bursting-01.eps")


# Simulation parameters
const T = 2000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

#Bifurcation diagrams
mKCabif , V = symbols("mKCabif,V", real=true)
PyPlot.close("all")
SymPy.plot_implicit(dV_mKCa_I(V,700.,1.5*6.,6.,30.,80.,25., mKCabif , Iapp1), (mKCabif,0.,1.), (V,-90.,50.), adaptive=false, points=500)
plot(mKCaa1[ceil(Int64,Tdt/2):Tdt],VV1[ceil(Int64,Tdt/2):Tdt],"-",color="black")
xlim(0,1)
ylim(-90,50)
@time BIF=bif_diag(1.,1., Iapp1, 200, 700.,1.5*6.,6.,30.,80.,25.)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
BIFmin_down=BIF[3]
BIFmax_down=BIF[4]
mKCaloop_up=linspace(1/200,1.,200)
mKCaloop_down=linspace(1.,1/200,200)
plot(mKCaloop_up,BIFmin_up,marker=".",linestyle="")
plot(mKCaloop_up,BIFmax_up,marker=".",linestyle="")
plot(mKCaloop_down,BIFmin_down,marker="*",linestyle="")
plot(mKCaloop_down,BIFmax_down,marker="*",linestyle="")
savefig("bif-burst-1.eps")

PyPlot.close("all")
SymPy.plot_implicit(dV_mKCa_I(V,700.,1.5*6.,6.,30.,80.,25., mKCabif , Iapp1), (mKCabif,0.,1.), (V,-90.,50.), adaptive=false, points=500)
plot(mKCaa1bis[ceil(Int64,Tdt/2):Tdt],VV1bis[ceil(Int64,Tdt/2):Tdt],"-",color="black")
xlim(0,1)
ylim(-90,50)
@time BIF=bif_diag(0.6,1., Iapp1bis, 200, 700.,1.5*6.,6.,30.,80.,25.)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
BIFmin_down=BIF[3]
BIFmax_down=BIF[4]
mKCaloop_up=linspace(1/200,1.,200)
mKCaloop_down=linspace(1.,1/200,200)
plot(mKCaloop_up,BIFmin_up,marker=".",linestyle="")
plot(mKCaloop_up,BIFmax_up,marker=".",linestyle="")
plot(mKCaloop_down,BIFmin_down,marker="*",linestyle="")
plot(mKCaloop_down,BIFmax_down,marker="*",linestyle="")
savefig("bif-burst-06.eps")

PyPlot.close("all")
SymPy.plot_implicit(dV_mKCa_I(V,700.,1.5*6.,6.,30.,80.,25., mKCabif , Iapp1), (mKCabif,0.,1.), (V,-90.,50.), adaptive=false, points=500)
plot(mKCaa1ter[ceil(Int64,Tdt/2):Tdt],VV1ter[ceil(Int64,Tdt/2):Tdt],"-",color="black")
xlim(0,1)
ylim(-90,50)
@time BIF=bif_diag(0.1,1., Iapp1ter, 200, 700.,1.5*6.,6.,30.,80.,25.)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
BIFmin_down=BIF[3]
BIFmax_down=BIF[4]
mKCaloop_up=linspace(1/200,1.,200)
mKCaloop_down=linspace(1.,1/200,200)
plot(mKCaloop_up,BIFmin_up,marker=".",linestyle="")
plot(mKCaloop_up,BIFmax_up,marker=".",linestyle="")
plot(mKCaloop_down,BIFmin_down,marker="*",linestyle="")
plot(mKCaloop_down,BIFmax_down,marker="*",linestyle="")
savefig("bif-burst-01.eps")


# Simulation parameters
const T = 5000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

#TONIC (700.,1.5*1,1.,240.,80.,25.) TONIC1=(700.,1.5*1,1.,30.,80.,25.)
#Timecourses
PyPlot.close("all")
@time yy2 = simulateSTG(1.,-20.,700.,1.5*1.,1.,240.,80.,25.)
VV2=yy2[1]
CCaa2=yy2[2]
Iapp2=yy2[3]
mKCaa2=yy2[4]
PyPlot.close("all")
subplot(3,1,1)
plot(t,VV2)
subplot(3,1,2)
plot(t,mKCaa2)
subplot(3,1,3)
plot(t,CCaa2)
savefig("timeplot-tonic-1.eps")

PyPlot.close("all")
@time yy2 = simulateSTG(0.6,-20.,700.,1.5*1.,1.,240.,80.,25.)
VV2bis=yy2[1]
CCaa2bis=yy2[2]
Iapp2bis=yy2[3]
mKCaa2bis=yy2[4]
PyPlot.close("all")
subplot(3,1,1)
plot(t,VV2bis)
subplot(3,1,2)
plot(t,mKCaa2bis)
subplot(3,1,3)
plot(t,CCaa2bis)
savefig("timeplot-tonic-06.eps")

PyPlot.close("all")
@time yy2 = simulateSTG(0.1,-20.,700.,1.5*1.,1.,240.,80.,25.)
VV2ter=yy2[1]
CCaa2ter=yy2[2]
Iapp2ter=yy2[3]
mKCaa2ter=yy2[4]
PyPlot.close("all")
subplot(3,1,1)
plot(t,VV2ter)
subplot(3,1,2)
plot(t,mKCaa2ter)
subplot(3,1,3)
plot(t,CCaa2ter)
savefig("timeplot-tonic-01.eps")


# Simulation parameters
const T = 2000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

#Bifurcation diagrams
mKCabif , V = symbols("mKCabif,V", real=true)
PyPlot.close("all")
SymPy.plot_implicit(dV_mKCa_I(V, 700.,1.5*1.,1.,240.,80.,25., mKCabif , Iapp2), (mKCabif,0.,1.), (V,-90.,50.), adaptive=false, points=500)
plot(mKCaa2[ceil(Int64,Tdt/2):Tdt],VV2[ceil(Int64,Tdt/2):Tdt],"-",color="black")
xlim(0,1)
ylim(-90,50)
@time BIF=bif_diag(1.,1., Iapp2, 200, 700.,1.5*1.,1.,240.,80.,25.)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
BIFmin_down=BIF[3]
BIFmax_down=BIF[4]
mKCaloop_up=linspace(1/200,1.,200)
mKCaloop_down=linspace(1.,1/200,200)
plot(mKCaloop_up,BIFmin_up,marker=".",linestyle="")
plot(mKCaloop_up,BIFmax_up,marker=".",linestyle="")
plot(mKCaloop_down,BIFmin_down,marker="*",linestyle="")
plot(mKCaloop_down,BIFmax_down,marker="*",linestyle="")
savefig("bif-tonic-1.eps")

PyPlot.close("all")
SymPy.plot_implicit(dV_mKCa_I(V, 700.,1.5*1.,1.,240.,80.,25., mKCabif , Iapp2), (mKCabif,0.,1.), (V,-90.,50.), adaptive=false, points=500)
plot(mKCaa2bis[ceil(Int64,Tdt/2):Tdt],VV2bis[ceil(Int64,Tdt/2):Tdt],"-",color="black")
xlim(0,1)
ylim(-90,50)
@time BIF=bif_diag(0.6,1., Iapp2bis, 200, 700.,1.5*1.,1.,240.,80.,25.)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
BIFmin_down=BIF[3]
BIFmax_down=BIF[4]
mKCaloop_up=linspace(1/200,1.,200)
mKCaloop_down=linspace(1.,1/200,200)
plot(mKCaloop_up,BIFmin_up,marker=".",linestyle="")
plot(mKCaloop_up,BIFmax_up,marker=".",linestyle="")
plot(mKCaloop_down,BIFmin_down,marker="*",linestyle="")
plot(mKCaloop_down,BIFmax_down,marker="*",linestyle="")
savefig("bif-tonic-06.eps")

PyPlot.close("all")
SymPy.plot_implicit(dV_mKCa_I(V, 700.,1.5*1.,1.,240.,80.,25., mKCabif , Iapp2), (mKCabif,0.,1.), (V,-90.,50.), adaptive=false, points=500)
plot(mKCaa2ter[ceil(Int64,Tdt/2):Tdt],VV2ter[ceil(Int64,Tdt/2):Tdt],"-",color="black")
xlim(0,1)
ylim(-90,50)
@time BIF=bif_diag(0.1,1., Iapp2ter, 200, 700.,1.5*1.,1.,240.,80.,25.)
BIFmin_up=BIF[1]
BIFmax_up=BIF[2]
BIFmin_down=BIF[3]
BIFmax_down=BIF[4]
mKCaloop_up=linspace(1/200,1.,200)
mKCaloop_down=linspace(1.,1/200,200)
plot(mKCaloop_up,BIFmin_up,marker=".",linestyle="")
plot(mKCaloop_up,BIFmax_up,marker=".",linestyle="")
plot(mKCaloop_down,BIFmin_down,marker="*",linestyle="")
plot(mKCaloop_down,BIFmax_down,marker="*",linestyle="")
savefig("bif-tonic-01.eps")

#mKCa_bif vs tauCa plot, BURSTING
tauCaloop = linspace(0.71,1.,30)
(SH,SN) = bif_detect_loop(tauCaloop,1., Iapp1,200,700.,1.5*6.,6.,30.,80.,25.)
PyPlot.close("all")
plot(tauCaloop,SH,marker="*",linestyle="")
plot(tauCaloop,SN,marker="*",linestyle="")
xlim(0,1.1)
ylim(0,1)
savefig("mKCa-tauCa-burst-zoom.eps")

#mKCa_bif vs tauCa plot, TONIC
(SH,SN) = bif_detect_loop(tauCaloop,1., Iapp2,200,700.,1.5*1.,1.,240.,80.,25.)
PyPlot.close("all")
plot(tauCaloop,SH,marker="*",linestyle="")
plot(tauCaloop,SN,marker="*",linestyle="")
xlim(0,1.1)
ylim(0,1)
savefig("mKCa-tauCa-tonic.eps")
