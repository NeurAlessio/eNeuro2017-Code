# Model from Goldman et al., 2001.

# gating functions
boltz(V::Float64,A::Float64,B::Float64) = 1/(1 + exp((V+A)/B))
tauX(V::Float64,A::Float64,B::Float64,D::Float64,E::Float64) = A - B/(1+exp((V+D)/E))
mNainf(V::Float64) = boltz(V,25.5,-5.29)
taumNa(V::Float64) = tauX(V,1.32,1.26,120.,-25.)
hNainf(V::Float64) = boltz(V,48.9,5.18)
tauhNa(V::Float64) = (0.67/(1+exp((V+62.9)/-10.0)))*(1.5 + 1/(1+exp((V+34.9)/3.6)))
mCaTinf(V::Float64) = boltz(V,27.1,-7.2)
  taumCaT(V::Float64,tauCa::Float64) = tauCa*tauX(V,21.7,21.3,68.1,-20.5)
hCaTinf(V::Float64) = boltz(V,32.1,5.5)
tauhCaT(V::Float64) = tauX(V,105.,89.8,55.,-16.9)
mCaSinf(V::Float64) = boltz(V,33.,-8.1)
  taumCaS(V::Float64,tauCa::Float64) = tauCa*(1.4 + (7/((exp((V+27)/10))+(exp((V+70)/-13)))))
hCaSinf(V::Float64) = boltz(V,60.,6.2)
tauhCaS(V::Float64) = 1.0(60 + (150/((exp((V+55)/9))+(exp((V+65)/-16)))))
mAinf(V::Float64) = boltz(V,27.2,-8.7)
taumA(V::Float64) = tauX(V,11.6,10.4,32.9,-15.2)
hAinf(V::Float64) = boltz(V,56.9,4.9)
tauhA(V::Float64) = tauX(V,38.6,29.2,38.9,-26.5)
mKCainf(V::Float64,Ca::Float64) = (Ca/(Ca+3))*(1/(1+exp((V+28.3)/-12.6)))
taumKCa(V::Float64) = tauX(V,90.3,75.1,46.,-22.7)
mKdinf(V::Float64) = boltz(V,12.3,-11.8)
taumKd(V::Float64) = tauX(V,7.2,6.4,28.3,-19.2)


function dV(V::Float64, mNa::Float64, hNa::Float64, mCaT::Float64, hCaT::Float64, mCaS::Float64, hCaS::Float64, mA::Float64, hA::Float64, mKCa::Float64, mKd::Float64, Ca::Float64, gNa::Float64, gCaT::Float64, gCaS::Float64, gA::Float64, gKd::Float64, gKCa::Float64, Iapp::Float64)
  (dt)*(1/C)*(-gNa*mNa^3*hNa*(V-VNa) -gCaT*mCaT^3*hCaT*(V-VCa) -gCaS*mCaS^3*hCaS*(V-VCa) -gA*mA^3*hA*(V-VK) -gKCa*mKCa^4*(V-VK) -gKd*mKd^4*(V-VK) -gleak*(V-Vleak) + Iapp)
end
const Vinf=-43.
dVinf(gNa::Float64, gCaS::Float64, gCaT::Float64, gA::Float64, gKd::Float64, gKCa::Float64) = C/dt*dV(Vinf, mNainf(Vinf), hNainf(Vinf), mCaTinf(Vinf), hCaTinf(Vinf), mCaSinf(Vinf), hCaSinf(Vinf), mAinf(Vinf), hAinf(Vinf), mKCainf(Vinf,0.5), mKdinf(Vinf), 0.5, gNa, gCaT, gCaS, gA, gKd, gKCa, 0.)

dmNa(V::Float64,mNa::Float64) = (dt)*((1/taumNa(V))*(mNainf(V) - mNa))
dhNa(V::Float64,hNa::Float64) = (dt)*((1/tauhNa(V))*(hNainf(V) - hNa))
dmCaT(V::Float64,mCaT::Float64,tauCa::Float64) = (dt)*((1/taumCaT(V,tauCa))*(mCaTinf(V) - mCaT))
dhCaT(V::Float64,hCaT::Float64) = (dt)*((1/tauhCaT(V))*(hCaTinf(V) - hCaT))
dmCaS(V::Float64,mCaS::Float64,tauCa::Float64) = (dt)*((1/taumCaS(V,tauCa))*(mCaSinf(V) - mCaS))
dhCaS(V::Float64,hCaS::Float64) = (dt)*((1/tauhCaS(V))*(hCaSinf(V) - hCaS))
dmA(V::Float64,mA::Float64) = (dt)*((1/taumA(V))*(mAinf(V) - mA))
dhA(V::Float64,hA::Float64) = (dt)*((1/tauhA(V))*(hAinf(V) - hA))
dmKCa(V::Float64,Ca::Float64,mKCa::Float64) = (dt)*((1/taumKCa(V))*(mKCainf(V,Ca) - mKCa))
dmKd(V::Float64,mKd::Float64) = (dt)*((1/taumKd(V))*(mKdinf(V) - mKd))
dCa(V::Float64,mCaT::Float64,hCaT::Float64,mCaS::Float64,hCaS::Float64,Ca::Float64,gCaS::Float64,gCaT::Float64) = (dt)*((-(0.94*10)*(gCaT*mCaT^3*hCaT*(V-VCa) +gCaS*mCaS^3*hCaS*(V-VCa)) - Ca + 0.05)/200)

function simulateSTG(tauCa::Float64, V0::Float64, gNa::Float64, gCaS::Float64, gCaT::Float64, gA::Float64, gKd::Float64, gKCa::Float64)
  V::Float64=copy(V0)
  Vtemp::Float64=copy(V0)
  Ca::Float64=10
  mNa::Float64=mNainf(V)
  hNa::Float64=hNainf(V)
  mCaT::Float64=mCaTinf(V)
  hCaT::Float64=0.15 #hCaTinf(V)
  mCaS::Float64=mCaSinf(V)
  hCaS::Float64=0.15 #hCaSinf(V)
  mA::Float64=mAinf(V)
  hA::Float64=0.05 #hAinf(V)
  mKCa::Float64=mKCainf(V,Ca)
  mKd::Float64=mKdinf(V)

  Iapp=-dVinf(gNa, gCaS, gCaT, gA, gKd, gKCa)+1.0
  VV = zeros(Tdt)
  CA = zeros(Tdt)
  mKCavec = zeros(Tdt)

  for z = 1:Tdt
    V += dV(V, mNa, hNa, mCaT, hCaT, mCaS, hCaS, mA, hA, mKCa, mKd, Ca, gNa, gCaT, gCaS, gA, gKd, gKCa, Iapp)
    mKCa += dmKCa(Vtemp,Ca,mKCa)
    Ca += dCa(Vtemp,mCaT,hCaT,mCaS,hCaS,Ca,gCaS,gCaT)
    mNa += dmNa(Vtemp,mNa)
    hNa += dhNa(Vtemp,hNa)
    mCaT += dmCaT(Vtemp,mCaT,tauCa)
    hCaT += 0*dhCaT(Vtemp,hCaT)
    mCaS += dmCaS(Vtemp,mCaS,tauCa)
    hCaS += 0*dhCaS(Vtemp,hCaS)
    mA += dmA(Vtemp,mA)
    hA += 0*dhA(Vtemp,hA)
    mKd += dmKd(Vtemp,mKd)

    VV[z] = copy(V)
    Vtemp=copy(V)
    CA[z] = copy(Ca)
    mKCavec[z] = copy(mKCa)
  end

  return VV, CA, Iapp, mKCavec
end

function simulateSTG_Ca(tauCa::Float64, V0::Float64, gNa::Float64, gCaS::Float64, gCaT::Float64, gA::Float64, gKd::Float64, gKCa::Float64,
  Ca::Float64,Iapp::Float64, mNa0::Float64, hNa0::Float64, mCaT0::Float64, mCaS0::Float64, mA0::Float64, mKCa0::Float64, mKd0::Float64,TdtCa::Int64)

  V::Float64=copy(V0)
  Vtemp::Float64=copy(V0)
  mNa::Float64=mNa0
  hNa::Float64=hNa0
  mCaT::Float64=mCaT0
        hCaT::Float64=0.15 #hCaTinf(V)
  mCaS::Float64=mCaS0 #mCaSinf(V)
        hCaS::Float64=0.15 #hCaSinf(V)
  mA::Float64=mA0 #mAinf(V)
        hA::Float64=0.05 #hAinf(V)
  mKCa::Float64=mKCa0 #mKCainf(V,Ca)
  mKd::Float64=mKd0 #mKdinf(V)

  VV = zeros(TdtCa)
  mNavec = zeros(TdtCa)
  hNavec = zeros(TdtCa)
  mCaTvec = zeros(TdtCa)
  mCaSvec = zeros(TdtCa)
  mAvec = zeros(TdtCa)
  mKCavec = zeros(TdtCa)
  mKdvec = zeros(TdtCa)

  for z = 1:TdtCa
    V += dV(V, mNa, hNa, mCaT, hCaT, mCaS, hCaS, mA, hA, mKCa, mKd, Ca, gNa, gCaT, gCaS, gA, gKd, gKCa, Iapp)
    mKCa += dmKCa(Vtemp,Ca,mKCa)
    mNa += dmNa(Vtemp,mNa)
    hNa += dhNa(Vtemp,hNa)
    mCaT += dmCaT(Vtemp,mCaT,tauCa)
    hCaT += 0*dhCaT(Vtemp,hCaT)
    mCaS += dmCaS(Vtemp,mCaS,tauCa)
    hCaS += 0*dhCaS(Vtemp,hCaS)
    mA += dmA(Vtemp,mA)
    hA += 0*dhA(Vtemp,hA)
    mKd += dmKd(Vtemp,mKd)

    VV[z] = copy(V)
    mNavec[z] = copy(mNa)
    hNavec[z] = copy(hNa)
    mCaTvec[z] = copy(mCaT)
    mCaSvec[z] = copy(mCaS)
    mAvec[z] = copy(mA)
    mKCavec[z] = copy(mKCa)
    mKdvec[z] = copy(mKd)
    Vtemp = copy(V)
  end

  return VV, mNavec, hNavec, mCaTvec, mCaSvec, mAvec, mKCavec, mKdvec
end


function simulateSTG_mKCa(tauCa::Float64, V0::Float64, gNa::Float64, gCaS::Float64, gCaT::Float64, gA::Float64, gKd::Float64, gKCa::Float64,
  Iapp::Float64, mNa0::Float64, hNa0::Float64, mCaT0::Float64, mCaS0::Float64, mA0::Float64, mKCa0::Float64, mKd0::Float64,TdtCa::Int64)

  V::Float64=copy(V0)
  Vtemp::Float64=copy(V0)
  mNa::Float64=mNa0
  hNa::Float64=hNa0
  mCaT::Float64=mCaT0
        hCaT::Float64=0.15 #hCaTinf(V)
  mCaS::Float64=mCaS0 #mCaSinf(V)
        hCaS::Float64=0.15 #hCaSinf(V)
  mA::Float64=mA0 #mAinf(V)
        hA::Float64=0.05 #hAinf(V)
  #mKCa::Float64=mKCa0 #mKCainf(V,Ca)
  mKd::Float64=mKd0 #mKdinf(V)

  VV = zeros(TdtCa)
  #mNavec = zeros(TdtCa)
  #hNavec = zeros(TdtCa)
  #mCaTvec = zeros(TdtCa)
  #mCaSvec = zeros(TdtCa)
  #mAvec = zeros(TdtCa)
  #mKCavec = zeros(TdtCa)
  #mKdvec = zeros(TdtCa)

  for z = 1:TdtCa
    V += dV(V, mNa, hNa, mCaT, hCaT, mCaS, hCaS, mA, hA, mKCa0, mKd, 0., gNa, gCaT, gCaS, gA, gKd, gKCa, Iapp)
    #mKCa += dmKCa(Vtemp,Ca,mKCa)
    mNa += dmNa(Vtemp,mNa)
    hNa += dhNa(Vtemp,hNa)
    mCaT += dmCaT(Vtemp,mCaT,tauCa)
    hCaT += 0*dhCaT(Vtemp,hCaT)
    mCaS += dmCaS(Vtemp,mCaS,tauCa)
    hCaS += 0*dhCaS(Vtemp,hCaS)
    mA += dmA(Vtemp,mA)
    hA += 0*dhA(Vtemp,hA)
    mKd += dmKd(Vtemp,mKd)

    VV[z] = copy(V)
    #mNavec[z] = copy(mNa)
    #hNavec[z] = copy(hNa)
    #mCaTvec[z] = copy(mCaT)
    #mCaSvec[z] = copy(mCaS)
    #mAvec[z] = copy(mA)
    #mKCavec[z] = copy(mKCa)
    #mKdvec[z] = copy(mKd)
    Vtemp = copy(V)
  end

  return VV, mNa, hNa, mCaT, mCaS, mA, mKd
end


# bifurcation diagram

function bif_diag(tauCa::Float64, mKCamax::Float64, Iapp::Float64, mKCalength::Int64, gNa::Float64, gCaS::Float64, gCaT::Float64, gA::Float64, gKd::Float64, gKCa::Float64)

  V0::Float64=-20.
  mNa0::Float64=0.9 #mNainf(V0)
  hNa0::Float64=0.9 #hNainf(V0)
  mCaT0::Float64=0.9 #mCaTinf(V0)
  mCaS0::Float64=0.9 #mCaSinf(V0)
  mA0::Float64=0.01 #mAinf(V0)
  #mKCa0::Float64=0.01 #mKCainf(V0,1.)
  mKd0::Float64=0.01 #mKdinf(V0)

  yy=simulateSTG_mKCa(tauCa,V0,gNa, gCaS, gCaT, gA, gKd, gKCa,
  Iapp, mNa0, hNa0, mCaT0, mCaS0, mA0, 0., mKd0,Tdt)

  Vfin=yy[1]
  Vfin=Vfin[end]

  mNa0=yy[2]
  hNa0=yy[3]
  mCaT0=yy[4]
  mCaS0=yy[5]
  mA0=yy[6]
  #mKCa0=yy[7]
  mKd0=yy[7]

  mKCaloop_up=linspace(1/mKCalength,1.,mKCalength)
  mKCaloop_down=linspace(1.,1/mKCalength,mKCalength)

  BIFmin_up=fill!(Array(Float64,mKCalength,1),NaN)
  BIFmax_up=fill!(Array(Float64,mKCalength,1),NaN)
  BIFmin_down=fill!(Array(Float64,mKCalength,1),NaN)
  BIFmax_down=fill!(Array(Float64,mKCalength,1),NaN)

  for i=1:length(mKCaloop_up)
    yy=simulateSTG_mKCa(tauCa,Vfin,gNa, gCaS, gCaT, gA, gKd, gKCa,
    Iapp, mNa0, hNa0, mCaT0, mCaS0, mA0, mKCaloop_up[i], mKd0,Tdt)
    Vfin=yy[1]

    BIFmin_up[i]=minimum(Vfin[ceil(Int64,Tdt/2):Tdt])
    BIFmax_up[i]=maximum(Vfin[ceil(Int64,Tdt/2):Tdt])

    Vfin=Vfin[end]

    mNa0=yy[2]
    hNa0=yy[3]
    mCaT0=yy[4]
    mCaS0=yy[5]
    mA0=yy[6]
    #mKCa0=yy[7]
    mKd0=yy[7]
  end

  for i=1:length(mKCaloop_down)
    yy=simulateSTG_mKCa(tauCa,Vfin,gNa, gCaS, gCaT, gA, gKd, gKCa,
    Iapp, mNa0, hNa0, mCaT0, mCaS0, mA0, mKCaloop_down[i], mKd0,Tdt)
    Vfin=yy[1]

    BIFmin_down[i]=minimum(Vfin[ceil(Int64,Tdt/2):Tdt])
    BIFmax_down[i]=maximum(Vfin[ceil(Int64,Tdt/2):Tdt])

    Vfin=Vfin[end]

    mNa0=yy[2]
    hNa0=yy[3]
    mCaT0=yy[4]
    mCaS0=yy[5]
    mA0=yy[6]
    #mKCa0=yy[7]
    mKd0=yy[7]
  end

  return BIFmin_up, BIFmax_up, BIFmin_down, BIFmax_down

end

# bifurcation diagram

function bif_detect(tauCa::Float64, mKCamax::Float64, Iapp::Float64, mKCalength::Int64, gNa::Float64, gCaS::Float64, gCaT::Float64, gA::Float64, gKd::Float64, gKCa::Float64)

  V0::Float64=-20.
  mNa0::Float64=0.9 #mNainf(V0)
  hNa0::Float64=0.9 #hNainf(V0)
  mCaT0::Float64=0.9 #mCaTinf(V0)
  mCaS0::Float64=0.9 #mCaSinf(V0)
  mA0::Float64=0.01 #mAinf(V0)
  #mKCa0::Float64=0.01 #mKCainf(V0,1.)
  mKd0::Float64=0.01 #mKdinf(V0)

  yy=simulateSTG_mKCa(tauCa,V0,gNa, gCaS, gCaT, gA, gKd, gKCa,
  Iapp, mNa0, hNa0, mCaT0, mCaS0, mA0, 0., mKd0,Tdt)

  Vfin2=yy[1]
  Vfin=Vfin2[end]
  mNa0=yy[2]
  hNa0=yy[3]
  mCaT0=yy[4]
  mCaS0=yy[5]
  mA0=yy[6]
  #mKCa0=yy[7]
  mKd0=yy[7]

  mKCaloop_up=linspace(1/mKCalength,1.,mKCalength)
  #mKCaloop_down=linspace(1.,1/mKCalength,mKCalength)

  SN = 0.
  SH = 0.
  temp = convert(Int64,1000/dt)

  for i=1:length(mKCaloop_up)
    yy=simulateSTG_mKCa(tauCa,Vfin,gNa, gCaS, gCaT, gA, gKd, gKCa,
    Iapp, mNa0, hNa0, mCaT0, mCaS0, mA0, mKCaloop_up[i], mKd0,Tdt)
    Vfin2=yy[1]
    Vfin=Vfin2[end]
    mNa0=yy[2]
    hNa0=yy[3]
    mCaT0=yy[4]
    mCaS0=yy[5]
    mA0=yy[6]
    mKd0=yy[7]
    #println(maximum(Vfin2[end-temp,end]))

    if maximum(Vfin2[end-temp:end]) < 0
      SH = copy(mKCaloop_up[i])
      break
    end

  end

  mKCaloop_down=linspace(SH+1/mKCalength,1/mKCalength,round((SH+1/mKCalength)*mKCalength))
  for i=1:length(mKCaloop_down)
    yy=simulateSTG_mKCa(tauCa,Vfin,gNa, gCaS, gCaT, gA, gKd, gKCa,
    Iapp, mNa0, hNa0, mCaT0, mCaS0, mA0, mKCaloop_down[i], mKd0,Tdt)
    Vfin2=yy[1]
    Vfin=Vfin2[end]
    mNa0=yy[2]
    hNa0=yy[3]
    mCaT0=yy[4]
    mCaS0=yy[5]
    mA0=yy[6]
    mKd0=yy[7]

    if maximum(Vfin2[end-temp:end]) > 0
      SN = copy(mKCaloop_down[i-1])
      break
    end
  end

  return SH, SN

end


function bif_detect_loop(tauCaloop::LinSpace{Float64},mKCamax::Float64, Iapp::Float64, mKCalength::Int64, gNa::Float64, gCaS::Float64, gCaT::Float64, gA::Float64, gKd::Float64, gKCa::Float64)
  SH = zeros(length(tauCaloop),1)
  SN = zeros(length(tauCaloop),1)
  for i=1:length(tauCaloop)
      println(i)
      (SH[i],SN[i])=bif_detect(tauCaloop[i],mKCamax, Iapp,mKCalength, gNa, gCaS, gCaT, gA, gKd, gKCa)
  end
  return SH, SN
end

# gating functions

boltz(V,A::Float64,B::Float64) = 1/(1 + exp((V+A)/B))
mNabif(V) = boltz(V,25.5,-5.29)
hNabif(V) = boltz(V,48.9,5.18)
mCaTbif(V) = boltz(V,27.1,-7.2)
hCaTbif(V) = 0.15 #boltz(V,32.1,5.5)
mCaSbif(V) = boltz(V,33.,-8.1)
hCaSbif(V) = 0.15 #boltz(V,60.,6.2)
mAbif(V) = boltz(V,27.2,-8.7)
hAbif(V) = 0.05 #boltz(V,56.9,4.9)
mKCabif2(V,Ca) = (Ca/(Ca+3))*(1/(1+exp((V+28.3)/-12.6)))
mKdbif(V) = boltz(V,12.3,-11.8)


dV_Ca_I(V,gNa::Float64, gCaS::Float64, gCaT::Float64, gA::Float64, gKd::Float64, gKCa::Float64, Ca, Iapp::Float64) =
-gNa*mNabif(V)^3*hNabif(V)*(V-VNa) -gCaT*mCaTbif(V)^3*hCaTbif(V)*(V-VCa) -gCaS*mCaSbif(V)^3*hCaSbif(V)*(V-VCa) -gA*mAbif(V)^3*hAbif(V)*(V-VK) -gKCa*mKCabif2(V,Ca)^4*(V-VK) -gKd*mKdbif(V)^4*(V-VK) -gleak*(V-Vleak) + Iapp

dV_mKCa_I(V,gNa::Float64, gCaS::Float64, gCaT::Float64, gA::Float64, gKd::Float64, gKCa::Float64, mKCabif, Iapp::Float64) =
-gNa*mNabif(V)^3*hNabif(V)*(V-VNa) -gCaT*mCaTbif(V)^3*hCaTbif(V)*(V-VCa) -gCaS*mCaSbif(V)^3*hCaSbif(V)*(V-VCa) -gA*mAbif(V)^3*hAbif(V)*(V-VK) -gKCa*mKCabif^4*(V-VK) -gKd*mKdbif(V)^4*(V-VK) -gleak*(V-Vleak) + Iapp
