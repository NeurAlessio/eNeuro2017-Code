# Defines output directory
#cd("/Users/gdrion/Dropbox/BurstingPaper/Julia code/Fig2/R15 SOPs/Results")

# Loads packages
using PyPlot
PyPlot.hold(false)

# Include model
include("R15_shift.jl")
#include("R15_VC.jl")

# Simulation parameters
const T = 50000
const Ttransient = 7000
const dt = 0.1
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const nsimu = 10
const z = 1.
const C = 1.
const VCa = 140.
const VK = -75.
const VNa = 30.
const Vl = -40.
const gNa = 4.*z
const gKd = 0.3*z
const gCa = 0.006*z #0.3-1
const gKCa = 0.04*z
const gl = 0.003*z
const k1 = 0.0085
const f = 0.0003
const lambda = 1/12.5

#const Iapp = 0.02
const tKd = 1.
const tCa = 0.01
const VCahalf = 50.
const k_Ca = 0.5

# @time (V, n, d, c) = simulateR15(0.8,gNa,gKd,gCa,gKCa,tKd,1.,k_Ca,0.02)
# @time (VSOP, nSOP, dSOP, cSOP) = simulateR15(0.8,0.,gKd,gCa,gKCa,tKd,1.,k_Ca,0.02)
# @time (Vf, nf, df, cf) = simulateR15(0.8,gNa,gKd,gCa,gKCa,tKd,0.01,k_Ca,0.02)
# @time (VfSOP, nfSOP, dfSOP, cfSOP) = simulateR15(0.8,0.,gKd,gCa,gKCa,tKd,0.01,k_Ca,0.02)
#
#
#
# figure(1)
# subplot(2,2,2)
# plot(t,V,"-")
# axis([Ttransient,T,-80,40])
# subplot(2,2,1)
# plot(t,VSOP,"-")
# axis([Ttransient,T,-80,40])
# subplot(2,2,4)
# plot(t,Vf,"-")
# axis([Ttransient,T,-80,40])
# subplot(2,2,3)
# plot(t,VfSOP,"-")
# axis([Ttransient,T,-80,40])
# savefig("Vplot_R15_SOP.eps")


figure(5)

@time (V, n, d, c) = simulateR15(0.8,gNa*1,gKd,gCa*0.8,gKCa,tKd,1.,k_Ca,-0.05)
@time (VSOP, nSOP, dSOP, cSOP) = simulateR15(0.8,0.,gKd,gCa*0.8,gKCa,tKd,1.,k_Ca,-0.05)
@time (Vf, nf, df, cf) = simulateR15(0.8,gNa/2,gKd,gCa*0.8,gKCa,tKd,0.01,k_Ca,-0.05)
@time (VfSOP, nfSOP, dfSOP, cfSOP) = simulateR15(0.8,0.,gKd,gCa*0.8,gKCa,tKd,0.01,k_Ca,-0.09)

subplot(2,2,2)
plot(t,V,"-")
axis([Ttransient,T,-80,40])
subplot(2,2,1)
plot(t,VSOP,"-")
axis([Ttransient,T,-80,40])
subplot(2,2,4)
plot(t,Vf,"-")
axis([Ttransient,T,-80,40])
subplot(2,2,3)
plot(t,VfSOP,"-")
axis([Ttransient,T,-80,40])
savefig("Vplot_R15_SOP.eps")


const Iapp = 0.02
# const Vlow = -100
# const Vhigh = 60
# const VV = linspace(Vlow,Vhigh,(Vhigh-Vlow)*100)
# figure(2)
# plot(VV,Istatic(VV,k_Ca))
# savefig("IVcurve_R15.eps")
#
#
# # Simulation parameters - Voltage clamp
# const Tstep = 1000
# const Tfinal = 8000
# const dt = 0.1
# const Tdtstep = convert(Int64,Tstep/dt)
# const Tdtfinal = convert(Int64,Tfinal/dt)
# const t = linspace(dt,Tfinal,Tdtfinal)
# #const V0 = -50.
# #const V1 = -40.
# const V0=-50.
# const V1=-40.
# @time Iclamp1 = simulateR15_VC(V0,V1,C,gNa,gKd,gCa,gKCa,tKd,1.,k_Ca)
# @time Iclamp2 = simulateR15_VC(V0,V1,C,gNa,gKd,gCa,gKCa,tKd,0.01,k_Ca)
# figure(3)
# #subplot(2,1,1)
# plot(t,Iclamp1)
# PyPlot.hold(true)
# #subplot(2,1,2)
# plot(t,Iclamp2,"r")
# savefig("VC_R15.eps")
# figure(4)
# #subplot(2,1,1)
# plot(t,Iclamp1)
# PyPlot.hold(true)
# #subplot(2,1,2)
# plot(t,Iclamp2,"r")
# axis([800,2000,-0.25,0.1])
# savefig("VC_R15_zoom.eps")
# PyPlot.hold(false)
