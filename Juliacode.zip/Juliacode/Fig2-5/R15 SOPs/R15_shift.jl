# gating functions
const Vshift=15
V2(V::Float64) = (127/105)*V + (8265/105)
alpham(V::Float64) = 0.1*(V2(V+Vshift)-50)/(1-exp((V2(V+Vshift)-50)/-10))
betam(V::Float64) = 4*exp((V2(V)-25)/-18)
minf(V::Float64) = alpham(V)/(alpham(V)+betam(V))
alphah(V::Float64) = 0.07*exp((V2(V)-25)/-20)
betah(V::Float64) = exp((V2(V)-55)/10)/(1+exp((V2(V)-55)/10))
hinf(V::Float64) = alphah(V)/(alphah(V)+betah(V))
tauh(V::Float64) = 1/(lambda*(alphah(V)+betah(V)))
alphan(V::Float64) = 0.01*(V2(V)-55)/(1-exp((V2(V)-55)/-10))
betan(V::Float64) = 0.125*exp((V2(V)-45)/-80)
ninf(V::Float64) = alphan(V)/(alphan(V)+betan(V))
taun(V::Float64) = 1/(lambda*(alphan(V)+betan(V)))
dinf(V::Float64) = 1/(exp(-0.15*(V+VCahalf))+1)
taud = 235
cinf(V::Float64) = k1*dinf(V)*(VCa-V)

function Istatic(V::LinSpace{Float64},k_Ca::Float64)
  I = zeros(length(V))
  for i=1:length(V)
    I[i] = -(-gNa*minf(V[i])^3*hinf(V[i])*(V[i]-VNa) -gCa*dinf(V[i])*(V[i]-VCa) -(gKd*ninf(V[i])^4 +gKCa*cinf(V[i])/(k_Ca+cinf(V[i])))*(V[i]-VK) -gl*(V[i]-Vl) + Iapp)
  end
  return I
end

function dV(C::Float64, V::Float64, h::Float64, n::Float64, d::Float64, c::Float64,gNa::Float64,gKd::Float64,gCa::Float64,gKCa::Float64,k_Ca::Float64,Iapp::Float64)
  (dt)*(1/C)*(-gNa*minf(V)^3*h*(V-VNa) -gCa*d*(V-VCa) -(gKd*n^4 +gKCa*c/(k_Ca+c))*(V-VK) -gl*(V-Vl) + Iapp)
end
dh(V::Float64,h::Float64,tKd::Float64) = (dt)*((1/(tKd*tauh(V)))*(hinf(V) - h))
dn(V::Float64,n::Float64,tKd::Float64) = (dt)*((1/(tKd*taun(V)))*(ninf(V) - n))
dd(V::Float64,d::Float64,tCa::Float64) = (dt)*((1/(tCa*taun(V)))*(dinf(V) - d))
dc(V::Float64,d::Float64,c::Float64) = (dt)*(f*(k1*d*(VCa-V) - c))

function simulateR15(C::Float64,gNa::Float64,gKd::Float64,gCa::Float64,gKCa::Float64,tKd::Float64,tCa::Float64,k_Ca::Float64,Iapp::Float64)
  V::Float64=-70.
  Vprev::Float64=-70.
  h::Float64=hinf(V)
  n::Float64=ninf(V)
  d::Float64=dinf(V)
  c::Float64 = k1*d*(VCa-V)

  VV = zeros(Tdt)
  nn = zeros(Tdt)
  dvec = zeros(Tdt)
  cc = zeros(Tdt)

  for z = 1:Tdt
    V += dV(C,V,h,n,d,c,gNa,gKd,gCa,gKCa,k_Ca,Iapp)
    c += dc(Vprev,d,c)
    h += dh(Vprev,h,tKd)
    n += dn(Vprev,n,tKd)
    d += dd(Vprev,d,tCa)

    Vprev = copy(V)
    VV[z] = copy(V)
    nn[z] = copy(n)
    dvec[z] = copy(d)
    cc[z] = copy(c)
  end

  return VV, nn, dvec, cc
end
