# gating functions
minf(V::Float64) = -(V/10 + 7/2)/((exp(- V/10 - 7/2) - 1)*(4*exp(- V/18 - 10/3) - (V/10 + 7/2)/(exp(- V/10 - 7/2) - 1)))
taum(V::Float64) = 1/(4*exp(- V/18 - 10/3) - (V/10 + 7/2)/(exp(- V/10 - 7/2) - 1))
hinf(V::Float64) = (7*exp(- V/20 - 3))/(100*((7*exp(- V/20 - 3))/100 + 1/(exp(- V/10 - 3) + 1)))
tauh(V::Float64) = 1/((7*exp(- V/20 - 3))/100 + 1/(exp(- V/10 - 3) + 1))
ninf(V::Float64) = -(V + 50)/((100*exp(- V/10 - 5) - 100)*(exp(- V/80 - 3/4)/8 - (V + 50)/(100*exp(- V/10 - 5) - 100)))
taun(V::Float64) = 1/(exp(- V/80 - 3/4)/8 - (V + 50)/(100*exp(- V/10 - 5) - 100))

function dV(V::Float64, m::Float64, h::Float64, n::Float64, Ca::Float64,gl::Float64,gCa::Float64,gKDR::Float64,gKCa::Float64)
  (dt)*(1/C)*(-gCa*m^3*h*(V-VCa) -gKDR*n^4*(V-VK) -gKCa*(Ca/(Ca+Kd))*(V-VK) - gl*(V-Vl) + Iapp)
end
dm(V::Float64,m::Float64) = (dt)*((1/taum(V+Vprime))*(minf(V+Vprime) - m))
dh(V::Float64,h::Float64) = (dt)*((1/tauh(V+Vprime))*(hinf(V+Vprime) - h))
dn(V::Float64,n::Float64) = (dt)*((1/taun(V+Vstar))*(ninf(V+Vstar) - n))
dCa(V::Float64,m::Float64,h::Float64,Ca::Float64,gCa::Float64) = (dt)*(f*(-k1*gCa*m^3*h*(V-VCa) -kc*Ca))


function simulateBC_spkt(gl::Float64,gCa::Float64,gKDR::Float64,gKCa::Float64)
  V::Float64=-55.
  Vprev::Float64=-55.
  Vprev2::Float64=-55.
  m::Float64=minf(V)
  h::Float64=hinf(V)
  n::Float64=ninf(V)
  Ca::Float64=0.8

  spk_time = zeros(1000,1)
  spk_height = zeros(1000,1)
  temp_times=1
  temp_height=1

  for z = 1:Tdt
    V += dV(V,m,h,n,Ca,gl,gCa,gKDR,gKCa)
    Ca += dCa(Vprev,m,h,Ca,gCa)
    m += dm(Vprev,m)
    h += dh(Vprev,h)
    n += dn(Vprev,n)

    if V>-35. && Vprev<-35.
      spk_time[temp_times]=t[z]
      temp_times += 1
    end

    if V>-35. && Vprev>Vprev2 && Vprev>=V
      spk_height[temp_height]=Vprev
      temp_height += 1
    end

    Vprev2 = copy(Vprev)
    Vprev = copy(V)
  end

  return spk_time,spk_height
end
