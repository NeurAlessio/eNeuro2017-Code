# gating functions
minf(V::Float64) = -(V/10 + 7/2)/((exp(- V/10 - 7/2) - 1)*(4*exp(- V/18 - 10/3) - (V/10 + 7/2)/(exp(- V/10 - 7/2) - 1)))
taum(V::Float64) = 1/(4*exp(- V/18 - 10/3) - (V/10 + 7/2)/(exp(- V/10 - 7/2) - 1))
hinf(V::Float64) = (7*exp(- V/20 - 3))/(100*((7*exp(- V/20 - 3))/100 + 1/(exp(- V/10 - 3) + 1)))
tauh(V::Float64) = 1/((7*exp(- V/20 - 3))/100 + 1/(exp(- V/10 - 3) + 1))
ninf(V::Float64) = -(V + 50)/((100*exp(- V/10 - 5) - 100)*(exp(- V/80 - 3/4)/8 - (V + 50)/(100*exp(- V/10 - 5) - 100)))
taun(V::Float64) = 1/(exp(- V/80 - 3/4)/8 - (V + 50)/(100*exp(- V/10 - 5) - 100))

function dV(V::Float64, m::Float64, h::Float64, n::Float64, Ca::Float64)
  (dt)*(1/C)*(-gCa*m^3*h*(V-VCa) -gKDR*n^4*(V-VK) -gKCa*(Ca/(Ca+Kd))*(V-VK) - gl*(V-Vl) + Iapp)
end
dm(V::Float64,m::Float64) = (dt)*((1/taum(V+Vprime))*(minf(V+Vprime) - m))
dh(V::Float64,h::Float64) = (dt)*((1/tauh(V+Vprime))*(hinf(V+Vprime) - h))
dn(V::Float64,n::Float64) = (dt)*((1/taun(V+Vstar))*(ninf(V+Vstar) - n))
dCa(V::Float64,m::Float64,h::Float64,Ca::Float64) = (dt)*(f*(-k1*gCa*m^3*h*(V-VCa) -kc*Ca))


function simulateBC(V0::Float64,V1::Float64,tstep::Float64)
  m::Float64=minf(V0)
  h::Float64=hinf(V0)
  n::Float64=ninf(V0)
  Ca::Float64=-(1/kc)*k1*gCa*m^3*h*(V0-VCa)

  Iout=zeros(Tdt)

  for z = 1:convert(Int64,tstep/dt)
    Ca += dCa(V0,m,h,Ca)
    m += dm(V0,m)
    h += dh(V0,h)
    n += dn(V0,n)

    Iout[z]=-dV(V0,m,h,n,Ca)
  end
  for z = convert(Int64,tstep/dt)+1:Tdt
    Ca += dCa(V1,m,h,Ca)
    m += dm(V1,m)
    h += dh(V1,h)
    n += dn(V1,n)

    Iout[z]=-dV(V1,m,h,n,Ca)
  end

  return Iout
end
