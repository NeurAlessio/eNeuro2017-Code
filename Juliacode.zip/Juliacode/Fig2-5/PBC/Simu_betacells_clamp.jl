# Defines output directory
#cd("")

# Loads packages
using PyPlot
PyPlot.hold(false)

# Include Connor-Stevens model
include("Betacells_clamp.jl")

# Simulation parameters
const T = 2000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const C = 1.
const VCa = 100.
const VK = -75.
const Vl = -40.
const gl = 0.012
const gCa = 3.2
const gKDR = 3.
const gKCa = 0.02
const k1 = 0.0275
const kc = 0.02
const f = 0.007
const Kd = 1.
const Vstar = 30-60
const Vprime = 50-60



const Iapp = -0.

# Simulation
@time Iout = simulateBC(-43.0,-42.0,200.)

# Save the results
#writedlm("continuousmodel.dat", VV)

# Plot the results
figure(1)
plot(t,Iout)
xlim(198,240)
ylim(0.001,0.00225)
#savefig("V-BC.eps")
