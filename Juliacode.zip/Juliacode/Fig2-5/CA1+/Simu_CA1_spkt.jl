# Defines output directory
cd("/Users/gdrion/Dropbox/BurstingPaper/Julia code/Fig2/CA1+/Results")

# Loads packages
using PyPlot
PyPlot.hold(false)

# Include DCN model
include("CA1_spkt.jl")
include("burstiness_map.jl")


# Simulation parameters
const T = 21000
const Ttransient = 1000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const nsimu = 100
const C = 0.4
const VNa = 55
const VK = -90
const VCa = 120
const Vleak = -62
const gleak = 0.05
const gNa = 35.
const gKd = 6.
const gNaP = 0.3
const gA = 1.4
const gM = 1.
const gc = 10.
const gsAHP = 5.
const gCa = 0.2
const Iapp = 0.

function simulateCA1_loop(nsimu,var)
  (spktimes,spkh) = simulateCA1_spkt(Iapp,C,gNa,gKd,gNaP,gA,gM,gc,gsAHP,gCa,gleak)
  spkt_height_nominal = mean(remove0(spkh))
  (PARAMS_nominal,freq_nominal) = compute_params(spktimes,Ttransient)
  variability = 1+(2*rand(nsimu,1)-1).*var
  gNavec = gNa.*variability
  gKdvec = gKd.*variability
  gNaPvec = gNaP.*variability
  gAvec = gA.*variability
  gMvec = gM.*variability
  gcvec = gc.*variability
  gsAHPvec = gsAHP.*variability
  gCavec = gCa.*variability
  gleakvec = gleak.*variability

  spkt_height = zeros(nsimu,1)
  PARAMS = zeros(nsimu,4)
  freq = zeros(nsimu,1)
  for i=1:nsimu
    (spktimes,spkh) = simulateCA1_spkt(Iapp,C,gNavec[i],gKdvec[i],gNaPvec[i],gAvec[i],gMvec[i],gcvec[i],gsAHPvec[i],gCavec[i],gleakvec[i])
    spkt_height[i] = mean(remove0(spkh))
    (PARAMS[i,:],freq[i]) = compute_params(spktimes,Ttransient)
  end
  return PARAMS_nominal,freq_nominal,spkt_height_nominal,PARAMS,freq,spkt_height
end


# Simulations
@time (PARAMS_nominal,freq_nominal,spkt_height_nominal,PARAMS1,freq1,spk_height1) = simulateCA1_loop(nsimu,0.12)

PyPlot.close("all")
figure(1)
PyPlot.hold(true)
plot(rand(length(PARAMS1[find(PARAMS1[:,1].>0),1])),log(PARAMS1[find(PARAMS1[:,1].>0),1]/PARAMS_nominal[1]),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-1.5,1.6])
PyPlot.hold(false)
savefig("SPB.eps")

figure(2)
PyPlot.hold(true)
plot(rand(length(PARAMS1[find(PARAMS1[:,2].>0),2])),log(PARAMS1[find(PARAMS1[:,2].>0),2]/PARAMS_nominal[2]),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-1,0.4])
PyPlot.hold(false)
savefig("PER.eps")

figure(3)
PyPlot.hold(true)
plot(rand(length(PARAMS1[find(PARAMS1[:,3].>0),3])),log(PARAMS1[find(PARAMS1[:,3].>0),3]/PARAMS_nominal[3]),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-1,0.4])
PyPlot.hold(false)
savefig("DC.eps")

figure(4)
PyPlot.hold(true)
plot(rand(length(PARAMS1[find(PARAMS1[:,4].>0),4])),log(PARAMS1[find(PARAMS1[:,4].>0),4]/PARAMS_nominal[4]),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-0.6,1.1])
PyPlot.hold(false)
savefig("IBF.eps")

figure(5)
PyPlot.hold(true)
plot(rand(length(freq1[find(freq1.>0)])),log(freq1[find(freq1.>0)]/freq_nominal),"ob")
ax = gca()
ax[:set_xlim]([-1,2])
PyPlot.hold(false)
savefig("freq.eps")

figure(6)
PyPlot.hold(true)
plot(rand(length(spk_height1)),spk_height1/spkt_height_nominal,"ob")
ax = gca()
ax[:set_xlim]([-1,2])
ax[:set_ylim]([-0.5,1.3])
PyPlot.hold(false)
savefig("Spike_height.eps")
