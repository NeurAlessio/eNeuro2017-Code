cd("./")

# Loads packages
using PyPlot
PyPlot.hold(true)


# Simulation parameters
const T = 1000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const C = 1.
const VNa = 50.
const VK = -80.
const VCa = 80.
const Vleak = -50.
const gleak = 0.1
const gNa = 1200.
const gCaT = 6.5  #1.-3.
const gCaS = gCaT*1.5
const gA = 100. #40. 80.
const gKd = 80. # 60. # 80.
const gKCa = 40. # 40. # 25.
const Iapp = 2.

const k1 = 0.3
#const k2 = 1.3

# Include DCN model
include("STG_2.jl")

# Simulation (Iapp)
@time yy = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy2 = simulateSTG(-60.,1./1.2,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy3 = simulateSTG(-60.,1./0.8,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,1000,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([300,1000,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([300,1000,-80,60])
savefig("Vplot_STG_C.eps")


@time yy = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy2 = simulateSTG(-60.,1.,Iapp,VNa+20.,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy3 = simulateSTG(-60.,1.,Iapp,VNa-20.,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,1000,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([300,1000,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([300,1000,-80,60])
savefig("Vplot_STG_VNa.eps")


@time yy = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy2 = simulateSTG(-60.,1.,Iapp,VNa,VK+5.,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy3 = simulateSTG(-60.,1.,Iapp,VNa,VK-5.,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,1000,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([300,1000,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([300,1000,-80,60])
savefig("Vplot_STG_VK.eps")


@time yy = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy2 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa-k1*gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy3 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa+k1*gNa,gCaT,gCaS,gA,gKd,gKCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,1000,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([300,1000,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([300,1000,-80,60])
savefig("Vplot_STG_gNa.eps")


@time yy = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy2 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd-k1*gKd,gKCa)
@time yy3 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd+k1*gKd,gKCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,1000,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([300,1000,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([300,1000,-80,60])
savefig("Vplot_STG_gKd.eps")


@time yy = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy2 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT-k1*gCaT,gCaS,gA,gKd,gKCa)
@time yy3 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT+k1*gCaT,gCaS,gA,gKd,gKCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,1000,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([300,1000,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([300,1000,-80,60])
savefig("Vplot_STG_gCaT.eps")


@time yy = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy2 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS-k1*gCaS,gA,gKd,gKCa)
@time yy3 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS+k1*gCaS,gA,gKd,gKCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,1000,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([300,1000,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([300,1000,-80,60])
savefig("Vplot_STG_gCaS.eps")


@time yy = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy2 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA-k1*gA,gKd,gKCa)
@time yy3 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA+k1*gA,gKd,gKCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,1000,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([300,1000,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([300,1000,-80,60])
savefig("Vplot_STG_gA.eps")


@time yy = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
@time yy2 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa-k1*gKCa)
@time yy3 = simulateSTG(-60.,1.,Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa+k1*gKCa)
PyPlot.close("all")
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,1000,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([300,1000,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([300,1000,-80,60])
savefig("Vplot_STG_gKCa.eps")


N=20
j=2
PyPlot.close("all")
figure
for i=1:N
    @time VV = simulateSTG(-60.,1.*(1+1/14-rand(1)[1]/7),Iapp,VNa*(1+1/14-rand(1)[1]/7),VK*(1+1/14-rand(1)[1]/7),VCa*(1+1/14-rand(1)[1]/7),gleak*(1+1/14-rand(1)[1]/7),gNa*(1+1/14-rand(1)[1]/7),gCaT*(1+1/14-rand(1)[1]/7),gCaS*(1+1/14-rand(1)[1]/7),gA*(1+1/14-rand(1)[1]/7),gKd*(1+1/14-rand(1)[1]/7),gKCa*(1+1/14-rand(1)[1]/7))
    subplot(N/j,j,i)
    Vplot = plot(t,VV,"-")
    axis([300,1000,-80,60])
end
savefig("Vplot_STG_rand.eps")
