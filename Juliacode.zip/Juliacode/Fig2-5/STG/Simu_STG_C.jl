cd("./")

# Loads packages
using PyPlot
PyPlot.hold(true)


# Simulation parameters
const T = 2000
const dt = 0.0001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)
const dt2 = 0.001
const Tdt2 = convert(Int64,T/dt2)
const t2 = linspace(dt2,T,Tdt2)
const dt3 = 0.00001
const Tdt3 = convert(Int64,round(T/dt3))
const t3 = linspace(dt3,T,Tdt3)


# Model parameters
const C = 1.
const VNa = 50.
const VK = -80.
const VCa = 80.
const Vleak = -50.
const gleak = 0.1
const gNa = 1200.
const gCaT = 6.5  #1.-3.
const gCaS = gCaT*1.5
const gA = 100. #40. 80.
const gKd = 80. # 60. # 80.
const gKCa = 40. # 40. # 25.
const Iapp = 2.

const k1 = 0.3
#const k2 = 1.3

# Include STG model
include("STG_2.jl")


# Simulation (Iapp)
N=4
j=1
Cvecplot=[0.1 1. 20. 80.]
PyPlot.close("all")
figure
for i=1:length(Cvecplot)
    @time VV = simulateSTG(-60.,Cvecplot[i],Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
    subplot(ceil(N/j),j,i)
    Vplot = plot(t,VV,"-")
    axis([500,T,-90,60])
end
savefig("Vplot_STG_Cplot.eps")


Cvec=logspace(0.,2.,100)
FP=zeros(length(Cvec))
for i=1:length(Cvec)
    @time (spiketimesA, spiketimesB) = simulateSTG_spkt(Tdt2,t2,-60.,Cvec[i],Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
    if sum(spiketimesA[1:end]) .== 0 && sum(spiketimesB[10:end]) .== 0
        FP[i] = 0. #Silent
    elseif sum(spiketimesA[1:end]) .> 0 && sum(spiketimesB[10:end]) .== 0
        FP[i] = 1. #Slow oscillation
    elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[10:end]))) ).== 1
        FP[i] = 2. #bursting
    else
        FP[i] = 3. #spiking
    end
end


Cvec2=logspace(-1.,0.,100)
FP2=zeros(length(Cvec2))
for i=1:length(Cvec2)
    @time (spiketimesA, spiketimesB) = simulateSTG_spkt(Tdt,t,-60.,Cvec2[i],Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
    if sum(spiketimesA[2:end]) .== 0 && sum(spiketimesB[10:end]) .== 0
        FP2[i] = 0. #Silent
    elseif sum(spiketimesA[2:end]) .> 0 && sum(spiketimesB[10:end]) .== 0
        FP2[i] = 1. #Slow oscillation
    elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[10:end]))) ).== 1
        FP2[i] = 2. #bursting
    else
        FP2[i] = 3. #spiking
    end
end

Cvec3=logspace(-2.,-1.,10)
FP3=zeros(length(Cvec3))
for i=1:length(Cvec3)
    @time (spiketimesA, spiketimesB) = simulateSTG_spkt(Tdt3,t3,-60.,Cvec3[i],Iapp,VNa,VK,VCa,gleak,gNa,gCaT,gCaS,gA,gKd,gKCa)
    if sum(spiketimesA[2:end]) .== 0 && sum(spiketimesB[10:end]) .== 0
        FP3[i] = 0. #Silent
    elseif sum(spiketimesA[2:end]) .> 0 && sum(spiketimesB[10:end]) .== 0
        FP3[i] = 1. #Slow oscillation
    elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[10:end]))) ).== 1
        FP3[i] = 2. #bursting
    else
        FP3[i] = 3. #spiking
    end
end

PyPlot.close("all")
figure
semilogx([Cvec3;Cvec2;Cvec],[FP3;FP2;FP],"*")
xlim([0.005,20])
ylim([-1,4])
savefig("Vplot_STG_FPvsC.eps")
