#cd("")

# Loads packages
using PyPlot
PyPlot.hold(true)


# Simulation parameters
const T = 1000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const C = 1.
const VNa = 50.
const VK = -80.
const VCa = 80.
const Vleak = -50.
const gleak = 0.1
const gNa = 1200.
const gCaT = 6.5  #1.-3.
const gCaS = gCaT*1.5
const gA = 100. #40. 80.
const gKd = 80. # 60. # 80.
const gKCa = 40. # 40. # 25.
const Iapp = 1.5

# Include DCN model
include("STG.jl")

# Simulation (Iapp)
@time yy = simulateSTG(-60.,1.,Iapp)
@time yy2 = simulateSTG(-60.,1./1.2,Iapp*1.2)
@time yy3 = simulateSTG(-60.,1./0.8,Iapp*0.8)
figure
subplot(3,1,1)
Vplot = plot(t,yy,"-")
axis([300,850,-80,60])
subplot(3,1,2)
Vplot = plot(t,yy2,"-")
axis([280,830,-80,60])
subplot(3,1,3)
Vplot = plot(t,yy3,"-")
axis([350,900,-80,60])
savefig("Vplot_STG.eps")
