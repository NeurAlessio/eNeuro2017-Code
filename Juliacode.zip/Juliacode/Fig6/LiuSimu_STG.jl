# Defines output directory
#cd("")

# Loads packages
using PyPlot
PyPlot.hold(false)

# Include DCN model
include("LiuSTG.jl")

# Simulation parameters
const T = 800
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Vclamp Simulation Parameters
const TVC = 100#5000
const T0 = 1
const Tdt0 = convert(Int64,T0/dt)
const TdtVC = convert(Int64,TVC/dt)
const tVC = linspace(dt,TVC,TdtVC)

# Model parameters
const z = 1

const VNa = 50.
const VK = -80.
const VCa = 80.
const VH = -20.
const Vleak = -50.
const gleak = 0.01*z
const gNa = 800.*z
const gA = 50.*z
const gKd = 90.*z
const gKCa = 60.*z
const gH = z*0.1

# #Bursting
# const gCaT = 4.*z
# const gCaS = 8.*z
#
# @time yy1 = simulateSTG(0.1,1.)
# @time Iclamp = simulateSTG_Vclamp(-44.,-42.)
# figure(1)
# subplot(3,1,1)
# plot(t,yy1,"-")
# axis([200,800,-80,60])
# subplot(3,1,2)
# Vplot=linspace(-80,-20,100)
# IVcurve_plot=IVcurve(Vplot)
# plot(Vplot,IVcurve_plot)
# axis([-80,-20,-10,50])
# subplot(3,1,3)
# plot(tVC,Iclamp)
# savefig("LiuSTG_bursting.eps")

#Tonic
const gCaT = 1.*z
const gCaS = 1.*z

## (Iapp,C)
@time yy1 = simulateSTG(0.1,1.)
@time Iclamp = simulateSTG_Vclamp(-44.,-42.)
figure(1)
subplot(3,1,1)
plot(t,yy1,"-")
axis([200,800,-80,60])
subplot(3,1,2)
Vplot=linspace(-80,-20,100)
IVcurve_plot=IVcurve(Vplot)
plot(Vplot,IVcurve_plot)
axis([-80,-20,-40,50])
subplot(3,1,3)
plot(tVC,Iclamp)
savefig("LiuSTG_tonic.eps")
