# Defines output directory
#cd("")
cd("./")

# Loads packages
using PyPlot
PyPlot.hold(false)


# Include STG model
include("STG.jl")
#include("burstiness_map.jl")

# Simulation parameters
const T = 3000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Vclamp Simulation Parameters
const TVC = 100#5000
const T0 = 1
const Tdt0 = convert(Int64,T0/dt)
const TdtVC = convert(Int64,TVC/dt)
const tVC = linspace(dt,TVC,TdtVC)

# Model parameters
const C = 1.
const VNa = 50.
const VK = -80.
const VCa = 80.
const Vleak = -50.
const gleak = 0.1
const gNa = 1200.
const gCaT = 10.  #1.-3.
const gCaS = 1.
const gA = 100. #40. 80.
const gKd = 80. # 60. # 80.
const gKCa = 50. # 40. # 25.
const Iapp = 1.

# Simulation (Iapp)
PyPlot.close("all")

# simulateSTG(V0,C,Iapp,gNa,gCaT,gCaS,gA,gKd,gKCa)
# simulateSTG_Vclamp(V0,V1,gNa,gCaT,gCaS,gA,gKd,gKCa)

@time (V,spk_times) = simulateSTG(-60.,1.,1.,1200.,10.,8.,10.,120.,50.)
@time Iclamp = simulateSTG_Vclamp(-44.,-42.,1200.,10.,8.,10.,120.,50.)
figure(1)
subplot(3,1,1)
plot(t,V,"-")
axis([1500,2000,-80,60])
subplot(3,1,2)
Vplot=linspace(-80,-20,100)
IVcurve_plot=IVcurve(Vplot)
plot(Vplot,IVcurve_plot)
axis([-80,-30,-5,20])
subplot(3,1,3)
plot(tVC,Iclamp)
ylim(-0.7,0.9)
savefig("STG_burst.eps")

@time (V,spk_times) = simulateSTG(-60.,1.,1.,1200.,1.,1.,10.,120.,20.)
@time Iclamp = simulateSTG_Vclamp(-44.,-42.,1200.,1.,1.,10.,120.,20.)
figure(2)
subplot(3,1,1)
Vplot = plot(t,V,"-")
axis([1500,2000,-80,60])
subplot(3,1,2)
Vplot=linspace(-80,-20,100)
IVcurve_plot=IVcurve(Vplot)
plot(Vplot,IVcurve_plot)
axis([-80,-30,-5,20])
subplot(3,1,3)
plot(tVC,Iclamp)
ylim(-1.5,0.1)
savefig("STG_tonic.eps")
