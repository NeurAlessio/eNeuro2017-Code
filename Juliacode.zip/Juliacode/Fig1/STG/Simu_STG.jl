cd("./")

# Loads packages
using PyPlot
PyPlot.hold(false)


# Simulation parameters
const T = 5000#5000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Vclamp Simulation Parameters
const TVC = 100  #5000
const T0 = 1
const Tdt0 = convert(Int64,T0/dt)
const TdtVC = convert(Int64,TVC/dt)
const tVC = linspace(dt,TVC,TdtVC)

# Model parameters
const C = 1.
const VNa = 50.
const VK = -80.
const VCa = 80.
const Vleak = -50.
const gleak = 0.1
#const gNa = 700.#700.
#const gCaT = 2.5  #1.-3.
#const gCaS = 7.0 #gCaT*1.5
#const gA = 30. #40. 80.
#const gKd = 80. # 60. # 80.
#const gKCa = 25. # 40. # 25.
#const Iapp = 0.

# Include STG model
include("STG.jl")
include("STG_Vclamp.jl")

# SimulateSTG(V0,gNa,gCaS,gCaT,gA,gKd,gKCa)
# SimulateSTG_Vclamp(V0,V1,gNa,gCaS,gCaT,gA,gKd,gKCa)
# IMinf(V,gNa, gCaS, gCaT, gA, gKd, gKCa, Ca, Iapp)

PyPlot.close("all")
@time yy = simulateSTG(-20.,700.,1.5*6.,6.,30.,80.,25.)
@time yyVC= simulateSTG_Vclamp(-40.,-39.,700.,1.5*6.,6.,30.,80.,25.)
figure(1)
subplot(2,1,1)
plot(t,yy[1],"-",color="black")
xlim(2050,2300)
ylim(-80,60)
subplot(2,1,2)
plot(tVC,yyVC,"-",color="black")
xlim(0,50)
#ylim(-0.7,0.3)
ylim(-1.5,0.8)
savefig("STG1.eps")



@time yy = simulateSTG(-20.,700.,1.5*1,1.,240.,80.,25.)
@time yyVC= simulateSTG_Vclamp(-40.,-39.,700.,1.5*1,1.,240.,80.,25.)
figure(2)
subplot(2,1,1)
plot(t,yy[1],"-",color="black")
xlim(2400,2650)
ylim(-80,60)
subplot(2,1,2)
plot(tVC,yyVC,"-",color="black")
xlim(0,50)
#ylim(0.7,1.7)
ylim(0.0,2.3)
savefig("STG2.eps")

#
#@time yy = simulateSTG(-20.,700.,1.5*3.,3.,26.,80.,25.)
@time yy = simulateSTG(-20.,700.,1.5*3.,3.,26.,80.,25.)
@time yyVC= simulateSTG_Vclamp(-40.,-39.,700.,1.5*3.,3.,26.,80.,25.)
figure(3)
subplot(2,1,1)
plot(t,yy[1],"-",color="black")
xlim(2450,2700)
ylim(-80,60)
subplot(2,1,2)
plot(tVC,yyVC,"-",color="black")
xlim(0,50)
#ylim(-0.5,0.5)
#ylim(-0.5,0.5)
savefig("STG3.eps")
#
@time yy = simulateSTG(-20.,700.,1.5*7,7.,225.,80.,25.)
@time yyVC= simulateSTG_Vclamp(-40.,-39.,700.,1.5*7,7.,225.,80.,25.)
figure(4)
subplot(2,1,1)
plot(t,yy[1],"-",color="black")
xlim(2250,2500)
ylim(-80,60)
subplot(2,1,2)
plot(tVC,yyVC,"-",color="black")
xlim(0,50)
#ylim(0.4,1.4)
#ylim(0.3,1.3)
savefig("STG4.eps")





#
# @time yy = simulateSTG(-20.,700.,1.5*5,5.,105.,80.,25.)
# @time yyVC= simulateSTG_Vclamp(-40.,-39.,700.,1.5*5,5.,105.,80.,25.)
# figure(5)
# subplot(2,1,1)
# plot(t,yy[1],"-",color="black")
# xlim(2450,2700)
# ylim(-80,60)
# subplot(2,1,2)
# plot(tVC,yyVC,"-",color="black")
# xlim(0,50)
# #ylim(-0.1,0.9)
# #ylim(-0.2,0.8)
# savefig("STG5.eps")
