cd("./")

# Loads packages
using PyPlot
PyPlot.hold(true)

# Include DCN model
include("STG_spktime.jl")
include("burstiness_map.jl")

# Simulation parameters
const T = 5000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const C = 0.5#0.685
const VNa = 50
const VK = -80
const VCa = 80
const Vleak = -50
const gleak = 0.1
const gNa = 700
const gCaT = 2.5  #0.5-3.
const gCaS = gCaT*1.5
const gA = 20. #20. 80.
const gKd = 80
const gKCa = 11

# Simulation (Iapp)
@time spk_time = simulateSTG_spk_time(0.5,-70.)
plot(spk_time,ones(1,length(spk_time)),"*")


burstiness=compute_params_1(spk_time,1500)
burstiness






#xlim(2000,3000)

#@time SimulateDCN_step()
#savefig("Vplot.eps")
