clear all
close all
clc

B100 = importdata('burstiness100vGD.dat');
B50 = importdata('burstiness50vGD.dat');
B40 = importdata('burstiness40vGD.dat');

B100(find(B100 == 0)) = NaN;
B50(find(B50 == 0)) = NaN;
B40(find(B40 == 0)) = NaN;

figure(1)
grid off
pcolor(B100)
caxis([0,1.5])
axis([0 100 0 100])
colormap jet
colorbar
saveas(figure(1),'b100.eps','epsc')

figure(2)
pcolor(B50)
caxis([0,1.5])
axis([0 100 0 100])
colormap jet
colorbar
saveas(figure(2),'b50.eps','epsc')

figure(3)
pcolor(B40)
caxis([0,1.5])
axis([0 100 0 100])
colormap jet
colorbar
saveas(figure(3),'b40.eps','epsc')
