# Functions
function ISIfunc(Spkt::Array{Float64})   # Computes the interspike intervals out of spike times
  ISI = zeros(5000)
  l::Int64 = 1
  for i = 2:length(Spkt)
      ISI[l] = Spkt[i] - Spkt[i-1]
      l += 1
  end
  return ISI
end

function remove0(ISI::Array{Float64})    # Removes 0's in spike times/interspike intervals vectors
  f = find(ISI .== 0)
    if f[1] > 1
      ISI = ISI[1:f[1]-1]
    else
      ISI = [0]
    end
  return ISI
end


function isbursting(ISI::Array{Float64})   # Check if the neuron is bursting using the rule 3*minISI < maxISI
  bursting::Int64 = 0
  if minimum(ISI)*3 < maximum(ISI)
      bursting = 1
  end
  return bursting
end

function SPB_PER_DC_IBFfunc(ISI::Array{Float64}) # Computes spike per burst (SPB), period (PER), duty cycle (DC) and mean intraburst frequency of bursting neurons.
  minISI = minimum(ISI)
  maxISI = maximum(ISI)
  interburst = find(ISI .>= maxISI/3)
  intraburst = find(ISI .<= maxISI/3)
  SPB = round(length(intraburst)/length(interburst))+1
  IBP = mean(ISI[intraburst])
  Burstdur = IBP*(SPB-1)
  PER = Burstdur+mean(ISI[interburst])
  DC = Burstdur/PER
  IBF = 1000/IBP
  return (SPB, PER, DC, IBF)
end

# function compute_params(spk_ncells::Array{Float64},Ttransient::Int64) # Extracts frequency or (SPB, PER, DC and IBF) out of the spiketimes saved in the Spkt$n.dat files. The number of cells is given by the number of lines in gs.
#   ncells = length(spk_ncells[:,1])
#   ISIs = zeros(1000)
#   PARAMS = zeros(ncells,4) #[SPB;PER;DC;IBF]
#   freq = zeros(ncells)
#   burstiness = zeros(ncells)
#   deltaISI = zeros(ncells)
#
#   for n = 1:ncells
#     #nbis = n-nEcells
#     f1 = find(spk_ncells[n,:] .>= Ttransient) #Removes the transient of depol period
#     f2 = find(spk_ncells[n,:] .== 0) #Removes the zeros at the end of the vector
#
#
#     if length(f1) == 0
#       Spkt = [0.]
#     else
#       Spkt = spk_ncells[n,f1[1]:f2[1]-1]
#     end
#
#     #if n <= nEcells
#     #  writedlm("Spktdepol_Ecell$n.dat",[Spkt_depol])
#     #  writedlm("Spkthyperpol_Ecell$n.dat",[Spkt_hyperpol])
#     #else
#     #  writedlm("Spktdepol_Icell$n.dat",[Spkt_depol])
#     #  writedlm("Spkthyperpol_Icell$n.dat",[Spkt_hyperpol])
#     #end
#
#     ISI = ISIfunc(Spkt)
#     ISItemp::Array{Float64} = remove0(ISI)
#
#     if isbursting(ISItemp) == 1
#       (PARAMS[n,1],PARAMS[n,2],PARAMS[n,3],PARAMS[n,4]) = SPB_PER_DC_IBFfunc(ISItemp)
#       #freq_depol[n] = 0.
#     else
#       PARAMS[n,:] = 0.
#       freq[n] = 1000/mean(ISItemp)
#     end
#
#     deltaISI[n]=log(maximum(ISItemp)/minimum(ISItemp))
#     burstiness[n]=deltaISI[n]*PARAMS[n,1]
#     #ISIs = [ISIs ISI]
#   end
#   #ISItemp = ISItemp[:,2:end]
#
#   #return PARAMS, freq, burstiness
#   return burstiness
# end

function compute_params_1(spk_time::Array{Float64},Ttransient::Int64) # Extracts frequency or (SPB, PER, DC and IBF) out of the spiketimes saved in the Spkt$n.dat files. The number of cells is given by the number of lines in gs.
  ISIs = zeros(1000)
  PARAMS = zeros(4) #[SPB;PER;DC;IBF]
  freq = 0.
  burstiness = 0.
  deltaISI = 0.

  f1 = find(spk_time .>= Ttransient) #Removes the transient of depol period
  f2 = find(spk_time .== 0) #Removes the zeros at the end of the vector


  if length(f1) == 0
    Spkt = [0.]
  else
    Spkt = spk_time[f1[1]:f2[1]-1]
  end

  ISI = ISIfunc(Spkt)
  ISItemp::Array{Float64} = remove0(ISI)

  if isbursting(ISItemp) == 1
    (PARAMS[1],PARAMS[2],PARAMS[3],PARAMS[4]) = SPB_PER_DC_IBFfunc(ISItemp)

    deltaISI=log(maximum(ISItemp)/minimum(ISItemp))

    #burstiness=PARAMS[1]*deltaISI
    #burstiness=PARAMS[1]*PARAMS[4]  #works good! v2
    #burstiness=PARAMS[1]*PARAMS[2] v3
    burstiness=PARAMS[1]/PARAMS[2]*PARAMS[4]

    return burstiness
  else
    PARAMS[:] = 0.
    freq = -1000/mean(ISItemp)

    return 0.
  end



end
