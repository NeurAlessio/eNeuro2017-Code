cd("./")

# Loads packages
using PyPlot
#using JLD

# Include DCN model
include("STG_burstiness.jl")
include("burstiness_map.jl")

# Simulation parameters
const T = 10000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = linspace(dt,T,Tdt)

# Model parameters
const C = 1.
const VNa = 50.
const VK = -80.
const VCa = 80.
const Vleak = -50.
const gleak = 0.1
const gNa = 700.
#const gCaT = 4.  #1.-3.
#const gCaS = gCaT*1.5
#const gA = 80. #40. 80.
const gKd = 80. # 80.   #_2::60.
const gKCa = 25. # 25.  #_2::40.

# Simulation (Iapp)
#const gCaTloop = linspace(1.0,3.0,11)
#const gAloop = linspace(40.,80.,11)

const gCaTloop = linspace(0.0,10.0,101)
const gAloop = linspace(0.,300.,101)

function burstiness_map_STG()

burstiness=zeros(length(gCaTloop),length(gAloop))

for i=1:length(gAloop)
  for j=1:length(gCaTloop)
    spk_time = simulateSTG_spk_time(-70.,gCaTloop[j],gAloop[i])
    burstiness[j,i]=compute_params_1(spk_time,2000)
  end
end

return burstiness

end

@time burstiness=burstiness_map_STG()

#plotly(size=(600,600))
#fig=heatmap(gCaT,gA,burstiness)

#save("burstiness100vGD.jld","burstiness",burstiness)
writedlm("burstiness50vGD.dat",burstiness)

figure(1)
pcolormesh(gAloop,gCaTloop,burstiness)
colorbar()
savefig("Burstiness.eps")
